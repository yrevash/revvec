############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Type stubs for ``AsyncVectorAIClient`` — asynchronous client.

These stubs restore IDE autocomplete for namespace methods that are
accessed through the async client's namespace properties.  Without
these stubs, ``client.collections.create(…)`` would show no signature
or return-type hints.

Generated from the corresponding async namespace classes
(``_collections.py``, ``_points.py``, ``_vde.py``).
"""

from __future__ import annotations

import builtins
from typing import Any

import numpy as np

from actian_vectorai.models.collections import (
    CollectionInfo,
    HnswConfigDiff,
    OptimizersConfigDiff,
    QuantizationConfig,
    QuantizationConfigDiff,
    VectorParams,
    VectorParamsDiff,
    WalConfigDiff,
)
from actian_vectorai.models.common import Filter, PointIdValue
from actian_vectorai.models.enums import (
    CollectionState,
    FieldType,
    IndexType,
    RebuildTaskState,
    ShardingMethod,
)
from actian_vectorai.models.points import (
    DenseVector,
    PointStruct,
    PrefetchQuery,
    RetrievedPoint,
    ScoredPoint,
    SearchParams,
    UpdateResult,
    WithPayloadSelector,
    WithVectorsSelector,
    WriteOrdering,
)
from actian_vectorai.models.vde import (
    CollectionStats,
    CompactOptions,
    CompactStats,
    OptimizationsResponse,
    RebuildDataSourceConfig,
    RebuildRunConfig,
    RebuildStats,
    RebuildTargetConfig,
    RebuildTaskInfo,
)

# ═══════════════════════════════════════════════════════════
#  Async namespace stubs
# ═══════════════════════════════════════════════════════════

class _AsyncCollections:
    """Stub for ``AsyncVectorAIClient.collections`` — collections namespace."""

    # ── CRUD ──

    async def create(
        self,
        name: str,
        *,
        vectors_config: VectorParams | dict[str, VectorParams] | None = None,
        hnsw_config: HnswConfigDiff | None = None,
        wal_config: WalConfigDiff | None = None,
        optimizers_config: OptimizersConfigDiff | None = None,
        quantization_config: QuantizationConfig | None = None,
        sparse_vectors_config: dict[str, Any] | None = None,
        shard_number: int | None = None,
        on_disk_payload: bool | None = None,
        replication_factor: int | None = None,
        write_consistency_factor: int | None = None,
        sharding_method: ShardingMethod | None = None,
        timeout: float | None = None,
        index_type: IndexType | None = None,
        ivf_config: Any | None = None,
        extra_params_json: str | None = None,
    ) -> bool: ...
    async def get_info(self, name: str, *, timeout: float | None = None) -> CollectionInfo: ...
    async def list(self, *, timeout: float | None = None) -> builtins.list[str]: ...
    async def delete(self, name: str, *, timeout: float | None = None) -> bool: ...
    async def exists(self, name: str, *, timeout: float | None = None) -> bool: ...
    async def update(
        self,
        name: str,
        *,
        optimizers_config: OptimizersConfigDiff | None = None,
        hnsw_config: HnswConfigDiff | None = None,
        vectors_config: dict[str, VectorParamsDiff] | None = None,
        quantization_config: QuantizationConfigDiff | None = None,
        sparse_vectors_config: dict[str, Any] | None = None,
        timeout: float | None = None,
        ivf_config: Any | None = None,
        vde_timeout: int | None = None,
    ) -> bool: ...

    # ── Convenience ──

    async def recreate(
        self,
        name: str,
        *,
        vectors_config: VectorParams | dict[str, VectorParams] | None = None,
        timeout: float | None = None,
        **kwargs: Any,
    ) -> bool: ...
    async def get_or_create(
        self,
        name: str,
        *,
        vectors_config: VectorParams | dict[str, VectorParams] | None = None,
        timeout: float | None = None,
        **kwargs: Any,
    ) -> CollectionInfo: ...

class _AsyncPoints:
    """Stub for ``AsyncVectorAIClient.points`` — points namespace."""

    # ── CRUD ──

    async def upsert(
        self,
        collection_name: str,
        points: list[PointStruct],
        *,
        wait: bool | None = None,
        ordering: WriteOrdering | None = None,
        timeout: float | None = None,
    ) -> UpdateResult: ...
    async def delete(
        self,
        collection_name: str,
        *,
        ids: list[PointIdValue] | None = None,
        filter: Filter | None = None,
        wait: bool | None = None,
        ordering: WriteOrdering | None = None,
        strict: bool = False,
        timeout: float | None = None,
    ) -> UpdateResult: ...
    async def get(
        self,
        collection_name: str,
        ids: list[PointIdValue],
        *,
        with_payload: bool | WithPayloadSelector = True,
        with_vectors: bool | WithVectorsSelector = False,
        timeout: float | None = None,
    ) -> list[RetrievedPoint]: ...
    async def update_vectors(
        self,
        collection_name: str,
        points: list[dict[str, Any]],
        *,
        wait: bool | None = None,
        ordering: WriteOrdering | None = None,
        timeout: float | None = None,
    ) -> UpdateResult: ...

    # ── Payload ──

    async def set_payload(
        self,
        collection_name: str,
        payload: dict[str, Any],
        *,
        ids: list[PointIdValue] | None = None,
        filter: Filter | None = None,
        wait: bool | None = None,
        ordering: WriteOrdering | None = None,
        key: str | None = None,
        timeout: float | None = None,
    ) -> UpdateResult: ...
    async def overwrite_payload(
        self,
        collection_name: str,
        payload: dict[str, Any],
        *,
        ids: list[PointIdValue] | None = None,
        filter: Filter | None = None,
        wait: bool | None = None,
        ordering: WriteOrdering | None = None,
        key: str | None = None,
        timeout: float | None = None,
    ) -> UpdateResult: ...
    async def delete_payload(
        self,
        collection_name: str,
        keys: list[str],
        *,
        ids: list[PointIdValue] | None = None,
        filter: Filter | None = None,
        wait: bool | None = None,
        ordering: WriteOrdering | None = None,
        timeout: float | None = None,
    ) -> UpdateResult: ...
    async def clear_payload(
        self,
        collection_name: str,
        *,
        ids: list[PointIdValue] | None = None,
        filter: Filter | None = None,
        wait: bool | None = None,
        ordering: WriteOrdering | None = None,
        timeout: float | None = None,
    ) -> UpdateResult: ...

    # ── Field Indexes ──

    async def create_field_index(
        self,
        collection_name: str,
        field_name: str,
        field_type: FieldType | None = None,
        *,
        field_index_params: Any | None = None,
        wait: bool | None = None,
        ordering: WriteOrdering | None = None,
        timeout: float | None = None,
    ) -> UpdateResult: ...

    # ── Search ──

    async def search(
        self,
        collection_name: str,
        vector: list[float] | np.ndarray[Any, Any] | DenseVector,
        *,
        limit: int = 10,
        filter: Filter | None = None,
        params: SearchParams | None = None,
        score_threshold: float | None = None,
        offset: int | None = None,
        using: str | None = None,
        with_payload: bool | WithPayloadSelector = True,
        with_vectors: bool | WithVectorsSelector = False,
        sparse_indices: list[int] | None = None,
        timeout: float | None = None,
    ) -> list[ScoredPoint]: ...
    async def search_batch(
        self,
        collection_name: str,
        searches: list[dict[str, Any]],
        *,
        timeout: float | None = None,
    ) -> list[list[ScoredPoint]]: ...

    # ── Count ──

    async def count(
        self,
        collection_name: str,
        *,
        filter: Filter | None = None,
        exact: bool = True,
        timeout: float | None = None,
    ) -> int: ...

    # ── Scroll ──

    async def scroll(
        self,
        collection_name: str,
        *,
        offset: PointIdValue | None = None,
        limit: int | None = None,
        filter: Filter | None = None,
        order_by: OrderBy | None = None,
        with_payload: bool | WithPayloadSelector = True,
        with_vectors: bool | WithVectorsSelector = False,
        consistency: ReadConsistency | None = None,
        shard_key_selector: Any | None = None,
        timeout: float | None = None,
    ) -> tuple[list[RetrievedPoint], PointIdValue | None]: ...
    async def scroll_all(
        self,
        collection_name: str,
        *,
        limit: int | None = None,
        filter: Filter | None = None,
        order_by: OrderBy | None = None,
        with_payload: bool | WithPayloadSelector = True,
        with_vectors: bool | WithVectorsSelector = False,
        consistency: ReadConsistency | None = None,
        shard_key_selector: Any | None = None,
        timeout: float | None = None,
    ): ...

    # ── Query (universal) ──

    async def query(
        self,
        collection_name: str,
        *,
        query: Any | None = None,
        prefetch: list[PrefetchQuery] | None = None,
        using: str | None = None,
        filter: Filter | None = None,
        params: SearchParams | None = None,
        score_threshold: float | None = None,
        limit: int = 10,
        offset: int | None = None,
        with_payload: bool | WithPayloadSelector = True,
        with_vectors: bool | WithVectorsSelector = False,
        lookup_from: dict[str, str] | None = None,
        timeout: float | None = None,
    ) -> list[ScoredPoint]: ...
    async def query_batch(
        self,
        collection_name: str,
        queries: list[dict[str, Any]],
        *,
        timeout: float | None = None,
    ) -> list[list[ScoredPoint]]: ...

    # ── Convenience ──

    async def upsert_single(
        self,
        collection_name: str,
        id: PointIdValue,
        vector: list[float] | np.ndarray[Any, Any],
        payload: dict[str, Any] | None = None,
        *,
        wait: bool | None = None,
        timeout: float | None = None,
    ) -> UpdateResult: ...
    async def delete_by_ids(
        self,
        collection_name: str,
        ids: list[PointIdValue],
        *,
        wait: bool | None = None,
        timeout: float | None = None,
    ) -> UpdateResult: ...

class _AsyncVDE:
    """Stub for ``AsyncVectorAIClient.vde`` — VDE extensions namespace."""

    # ── Lifecycle ──

    async def open_collection(self, name: str, *, timeout: float | None = None) -> bool: ...
    async def close_collection(self, name: str, *, timeout: float | None = None) -> bool: ...

    # ── Persistence ──

    async def save_snapshot(self, name: str, *, timeout: float | None = None) -> bool: ...
    async def load_snapshot(self, name: str, *, timeout: float | None = None) -> bool: ...

    # ── Status & Statistics ──

    async def get_state(self, name: str, *, timeout: float | None = None) -> CollectionState: ...
    async def get_vector_count(self, name: str, *, timeout: float | None = None) -> int: ...
    async def get_stats(self, name: str, *, timeout: float | None = None) -> CollectionStats: ...
    async def get_optimizations(
        self,
        name: str,
        *,
        include_completed: bool | None = None,
        completed_limit: int | None = None,
        timeout: float | None = None,
    ) -> OptimizationsResponse: ...

    # ── Maintenance ──

    async def flush(self, name: str, *, timeout: float | None = None) -> bool: ...
    async def rebuild_index(self, name: str, *, timeout: float | None = None) -> bool: ...
    async def optimize(self, name: str, *, timeout: float | None = None) -> bool: ...

    # ── Rebuild Management ──

    async def trigger_rebuild(
        self,
        name: str,
        *,
        source: RebuildDataSourceConfig | None = None,
        target: RebuildTargetConfig | None = None,
        run_config: RebuildRunConfig | None = None,
        wait: bool | None = None,
        wait_timeout: int | None = None,
        priority: int | None = None,
        timeout: float | None = None,
    ) -> tuple[str, RebuildStats | None]: ...
    async def get_rebuild_task(
        self,
        task_id: str,
        *,
        timeout: float | None = None,
    ) -> RebuildTaskInfo: ...
    async def list_rebuild_tasks(
        self,
        *,
        collection_name: str | None = None,
        state: RebuildTaskState | None = None,
        limit: int | None = None,
        offset: int | None = None,
        timeout: float | None = None,
    ) -> tuple[list[RebuildTaskInfo], int]: ...
    async def cancel_rebuild_task(
        self,
        task_id: str,
        *,
        timeout: float | None = None,
    ) -> bool: ...

    # ── Advanced Operations ──

    async def compact_collection(
        self,
        name: str,
        *,
        options: CompactOptions | None = None,
        wait: bool | None = None,
        wait_timeout: int | None = None,
        timeout: float | None = None,
    ) -> tuple[str, CompactStats | None]: ...

# ═══════════════════════════════════════════════════════════
#  Async client
# ═══════════════════════════════════════════════════════════

class AsyncVectorAIClient:
    """Asynchronous client for Actian VectorAI DB.

    Provides ``async`` / ``await`` access to all VectorAI DB operations
    through typed namespace properties.
    """

    def __init__(
        self,
        url: str = "localhost:50051",
        *,
        api_key: str | None = None,
        tls: bool = False,
        tls_ca_cert: str | None = None,
        tls_client_cert: str | None = None,
        tls_client_key: str | None = None,
        timeout: float | None = 30.0,
        max_message_size: int = ...,
        max_retries: int = 3,
        pool_size: int = 1,
        enable_tracing: bool = True,
        enable_logging: bool = False,
        metadata: dict[str, str] | None = None,
        grpc_options: list[tuple[str, Any]] | None = None,
    ) -> None: ...

    # ── Typed namespace properties ────────────────────────────

    @property
    def collections(self) -> _AsyncCollections: ...
    @property
    def points(self) -> _AsyncPoints: ...
    @property
    def vde(self) -> _AsyncVDE: ...
    @property
    def is_connected(self) -> bool: ...

    # ── Connection lifecycle ──────────────────────────────────

    async def connect(self) -> None: ...
    async def close(self) -> None: ...
    async def __aenter__(self) -> AsyncVectorAIClient: ...
    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None: ...

    # ── Top-level convenience ─────────────────────────────────

    async def health_check(self, *, timeout: float | None = None) -> dict[str, Any]: ...
    async def upload_points(
        self,
        collection_name: str,
        points: list[PointStruct],
        *,
        batch_size: int = 256,
    ) -> int: ...
    def __repr__(self) -> str: ...
