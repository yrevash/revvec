############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Thread-safe circuit breaker for Actian VectorAI client.

State machine::

    CLOSED → (failure threshold reached) → OPEN
    OPEN → (recovery timeout elapsed) → HALF_OPEN
    HALF_OPEN → (probe succeeds) → CLOSED
    HALF_OPEN → (probe fails) → OPEN
"""

from __future__ import annotations

import enum
import threading
import time

__all__ = ["CircuitBreaker", "CircuitState"]


class CircuitState(enum.Enum):
    """Circuit breaker state."""

    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreaker:
    """Thread-safe circuit breaker.

    Parameters
    ----------
    failure_threshold:
        Number of consecutive failures to trip open (default: 5).
    recovery_timeout:
        Seconds before attempting half-open probe (default: 30).
    success_threshold:
        Consecutive successes in half-open to fully close (default: 2).
    """

    __slots__ = (
        "_failure_threshold",
        "_recovery_timeout",
        "_success_threshold",
        "_state",
        "_failure_count",
        "_success_count",
        "_last_failure_time",
        "_lock",
    )

    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: float = 30.0,
        success_threshold: int = 2,
    ) -> None:
        self._failure_threshold = failure_threshold
        self._recovery_timeout = recovery_timeout
        self._success_threshold = success_threshold
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._last_failure_time = 0.0
        self._lock = threading.RLock()

    @property
    def state(self) -> CircuitState:
        """Current circuit state (auto-transitions OPEN → HALF_OPEN)."""
        with self._lock:
            if self._state == CircuitState.OPEN:
                if time.monotonic() - self._last_failure_time >= self._recovery_timeout:
                    self._state = CircuitState.HALF_OPEN
                    self._success_count = 0
            return self._state

    @property
    def failure_count(self) -> int:
        """Current consecutive failure count."""
        with self._lock:
            return self._failure_count

    def _maybe_transition_to_half_open(self) -> None:
        """Perform OPEN → HALF_OPEN if the recovery timeout has elapsed.

        Must be called while holding ``_lock``.
        """
        if self._state == CircuitState.OPEN:
            if time.monotonic() - self._last_failure_time >= self._recovery_timeout:
                self._state = CircuitState.HALF_OPEN
                self._success_count = 0

    def record_success(self) -> None:
        """Record a successful operation."""
        with self._lock:
            self._maybe_transition_to_half_open()
            if self._state == CircuitState.HALF_OPEN:
                self._success_count += 1
                if self._success_count >= self._success_threshold:
                    self._state = CircuitState.CLOSED
                    self._failure_count = 0
            elif self._state == CircuitState.CLOSED:
                self._failure_count = 0

    def record_failure(self) -> None:
        """Record a failed operation."""
        with self._lock:
            self._maybe_transition_to_half_open()
            self._failure_count += 1
            self._last_failure_time = time.monotonic()
            if self._state == CircuitState.HALF_OPEN:
                self._state = CircuitState.OPEN
            elif self._failure_count >= self._failure_threshold:
                self._state = CircuitState.OPEN

    def ensure_closed(self) -> None:
        """Raise :class:`CircuitBreakerOpenError` if the circuit is open."""
        if self.state == CircuitState.OPEN:
            from actian_vectorai.exceptions import CircuitBreakerOpenError

            remaining = self._recovery_timeout - (time.monotonic() - self._last_failure_time)
            raise CircuitBreakerOpenError(max(0, remaining), self._failure_count)

    def reset(self) -> None:
        """Force-reset the circuit breaker to CLOSED."""
        with self._lock:
            self._state = CircuitState.CLOSED
            self._failure_count = 0
            self._success_count = 0

    def __repr__(self) -> str:
        return (
            f"CircuitBreaker(state={self.state.value}, "
            f"failures={self._failure_count}/{self._failure_threshold})"
        )
