############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Configurable retry policy for Actian VectorAI client.

Extracted from the interceptor layer to provide a user-configurable
retry configuration that can be passed to the client constructor.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import FrozenSet

import grpc

__all__ = ["RetryConfig"]


@dataclass(frozen=True)
class RetryConfig:
    """User-configurable retry policy.

    Parameters
    ----------
    max_retries:
        Maximum number of retry attempts (default: 3).
    initial_backoff_ms:
        Initial backoff delay in milliseconds (default: 100).
    max_backoff_ms:
        Maximum backoff delay cap in milliseconds (default: 5000).
    backoff_multiplier:
        Multiplier for exponential backoff (default: 2.0).
    jitter_factor:
        Random jitter factor (0.0 - 1.0) added to backoff (default: 0.25).
    retryable_status_codes:
        gRPC status codes eligible for retry.
    retryable_http_codes:
        HTTP status codes eligible for retry (for REST transport).
    """

    max_retries: int = 3
    initial_backoff_ms: int = 100
    max_backoff_ms: int = 5_000
    backoff_multiplier: float = 2.0
    jitter_factor: float = 0.25
    retryable_status_codes: FrozenSet[grpc.StatusCode] = field(
        default_factory=lambda: frozenset(
            {
                grpc.StatusCode.UNAVAILABLE,
                grpc.StatusCode.RESOURCE_EXHAUSTED,
                grpc.StatusCode.ABORTED,
            }
        )
    )
    retryable_http_codes: FrozenSet[int] = field(
        default_factory=lambda: frozenset({429, 502, 503, 504})
    )

    def compute_delay(self, attempt: int) -> float:
        """Calculate the retry delay in seconds for a given attempt.

        Parameters
        ----------
        attempt:
            Current attempt number (0-based).

        Returns
        -------
        Delay in seconds.
        """
        delay_ms = self.initial_backoff_ms * (self.backoff_multiplier**attempt)
        delay_ms = min(delay_ms, self.max_backoff_ms)
        jitter = random.uniform(0, self.jitter_factor * delay_ms)
        return (delay_ms + jitter) / 1000.0
