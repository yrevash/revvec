############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Backpressure controls for Actian VectorAI client.

Provides semaphore-based concurrency limiting and server-coordinated
throttling via response metadata signals.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass

__all__ = ["BackpressureController", "BackpressureConfig"]

logger = logging.getLogger("actian_vectorai.resilience.backpressure")


@dataclass
class BackpressureConfig:
    """Backpressure tuning knobs.

    Parameters
    ----------
    max_concurrent_requests:
        Maximum in-flight requests across all operations.
    initial_concurrency:
        Starting concurrency level (scales up/down dynamically).
    min_concurrency:
        Minimum concurrency floor.
    max_concurrency:
        Maximum concurrency ceiling.
    """

    max_concurrent_requests: int = 64
    initial_concurrency: int = 16
    min_concurrency: int = 1
    max_concurrency: int = 64


class BackpressureController:
    """Semaphore-based concurrency controller with dynamic adjustment.

    Parses server-side backpressure signals from response headers:
    - ``retry-after``: Explicit delay in seconds.
    - ``x-actian-backpressure``: Server load factor (0.0 to 1.0).
    """

    __slots__ = ("_config", "_semaphore", "_current_limit")

    def __init__(self, config: BackpressureConfig | None = None) -> None:
        self._config = config or BackpressureConfig()
        self._current_limit = self._config.initial_concurrency
        self._semaphore = asyncio.Semaphore(self._current_limit)

    @property
    def current_limit(self) -> int:
        """Current concurrency limit."""
        return self._current_limit

    async def acquire(self) -> None:
        """Acquire a concurrency slot (blocks if limit reached)."""
        await self._semaphore.acquire()

    def release(self) -> None:
        """Release a concurrency slot."""
        self._semaphore.release()

    async def process_server_signals(self, metadata: dict[str, str]) -> None:
        """Adjust concurrency based on server backpressure signals.

        Parameters
        ----------
        metadata:
            Response metadata (gRPC trailing metadata or HTTP headers).
        """
        retry_after = metadata.get("retry-after")
        if retry_after:
            try:
                delay = float(retry_after)
                logger.info("Server backpressure: sleeping %.1fs", delay)
                await asyncio.sleep(delay)
            except ValueError:
                pass

        backpressure = metadata.get("x-actian-backpressure")
        if backpressure:
            try:
                load = float(backpressure)
            except ValueError:
                return

            if load > 0.8 and self._current_limit > self._config.min_concurrency:
                new_limit = max(self._config.min_concurrency, self._current_limit - 1)
                self._adjust_semaphore(new_limit)
                logger.warning(
                    "Server load %.0f%%, reducing concurrency to %d",
                    load * 100,
                    self._current_limit,
                )
            elif load < 0.3 and self._current_limit < self._config.max_concurrency:
                new_limit = self._current_limit + 1
                self._adjust_semaphore(new_limit)
                logger.info(
                    "Server load %.0f%%, increasing concurrency to %d",
                    load * 100,
                    self._current_limit,
                )

    def _adjust_semaphore(self, new_limit: int) -> None:
        """Adjust semaphore to match new concurrency limit."""
        diff = new_limit - self._current_limit
        self._current_limit = new_limit
        if diff > 0:
            # Increase: release extra slots
            for _ in range(diff):
                self._semaphore.release()
        elif diff < 0:
            # Decrease: drain slots (best-effort, non-blocking).
            # asyncio.Semaphore has no public acquire_nowait, so we
            # decrement the internal counter directly when slots are
            # available.  This is safe because we only reduce by the
            # exact diff and break if no more slots are free.
            for _ in range(-diff):
                if not self._semaphore.locked():
                    self._semaphore._value -= 1
                else:
                    break

    def __repr__(self) -> str:
        return (
            f"BackpressureController(limit={self._current_limit}, "
            f"max={self._config.max_concurrent_requests})"
        )
