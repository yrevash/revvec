############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Structured exception hierarchy for the Actian VectorAI DB Python client.

All exceptions derive from :class:`VectorAIError`.  The
:func:`from_grpc_error` factory maps gRPC ``RpcError`` instances to the
correct subclass so callers can catch precisely the error they care about.

Quick reference::

    VectorAIError
    ├── ConnectionError
    │   ├── ConnectionRefusedError
    │   ├── ConnectionTimeoutError
    │   └── ChannelClosedError
    ├── AuthenticationError
    │   ├── InvalidCredentialsError
    │   └── PermissionDeniedError
    ├── CollectionError
    │   ├── CollectionNotFoundError
    │   ├── CollectionExistsError
    │   └── CollectionNotReadyError
    ├── PointError
    │   ├── PointNotFoundError
    │   └── DimensionMismatchError
    ├── ValidationError
    ├── IndexError
    ├── ServerError
    │   └── UnimplementedError
    ├── TimeoutError
    ├── RateLimitError
    └── BatchError
"""

from __future__ import annotations

import enum
import random
from typing import Any, Dict, Optional

# ============================================================================
#  Client-side error codes
# ============================================================================


class ErrorCode(enum.IntEnum):
    """HTTP-aligned error codes for VectorAI exceptions.

    Values mirror standard HTTP status codes so that the meaning is
    immediately familiar to anyone who knows HTTP.  Multiple exception
    classes may share the same code (e.g. both ``CollectionNotFoundError``
    and ``PointNotFoundError`` use ``NOT_FOUND = 404``).
    """

    BAD_REQUEST           = 400  # Malformed input / invalid argument
    UNAUTHORIZED          = 401  # Invalid or missing credentials
    FORBIDDEN             = 403  # Insufficient permissions
    NOT_FOUND             = 404  # Resource (collection, point) does not exist
    REQUEST_TIMEOUT       = 408  # Operation deadline exceeded
    CONFLICT              = 409  # Resource already exists
    UNPROCESSABLE_ENTITY  = 422  # Semantic validation failure (dimension, field)
    TOO_MANY_REQUESTS     = 429  # Rate limit or resource quota exceeded
    INTERNAL_SERVER_ERROR = 500  # Server-side or index error
    NOT_IMPLEMENTED       = 501  # Operation not supported by the server
    BAD_GATEWAY           = 502  # Upstream/proxy returned an invalid response
    SERVICE_UNAVAILABLE   = 503  # Server unreachable / connection refused / closed
    GATEWAY_TIMEOUT       = 504  # Connection attempt timed out

# ============================================================================
#  Base
# ============================================================================


class VectorAIError(Exception):
    """Root exception for all Actian VectorAI DB client errors.

    Attributes:
        message:   Human-readable error description.
        code:      :class:`ErrorCode` value (int) identifying the error category, or ``None``.
        details:   Extra debugging information (available for programmatic access only).
        operation: Name of the RPC / method that failed.
    """

    def __init__(
        self,
        message: str = "",
        *,
        code: Optional[int] = None,
        details: Optional[str] = None,
        operation: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.code = code
        self.details = details
        self.operation = operation

    def __str__(self) -> str:
        parts = [self.message]
        if self.code is not None:
            try:
                ec = ErrorCode(self.code)
                parts.append(f"code={ec.value} ({ec.name})")
            except ValueError:
                parts.append(f"code={self.code}")
        return " | ".join(parts)

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}("
            f"message={self.message!r}, "
            f"code={self.code}, "
            f"operation={self.operation!r})"
        )


# ============================================================================
#  Connection errors
# ============================================================================


class ConnectionError(VectorAIError):  # noqa: A001 (intentional shadow)
    """Cannot establish or maintain a connection to the server."""


class ConnectionRefusedError(ConnectionError):  # noqa: A001
    """Server refused the connection (not running / wrong address)."""

    def __init__(self, address: str, *, details: Optional[str] = None) -> None:
        super().__init__(
            f"Cannot connect to VectorAI DB server at '{address}'",
            code=ErrorCode.SERVICE_UNAVAILABLE,
            details=details,
        )
        self.address = address


class ConnectionTimeoutError(ConnectionError):
    """Connection attempt timed out."""

    def __init__(self, address: str, timeout: float) -> None:
        super().__init__(
            f"Connection to '{address}' timed out after {timeout}s",
            code=ErrorCode.GATEWAY_TIMEOUT,
        )
        self.address = address
        self.timeout = timeout


class ChannelClosedError(ConnectionError):
    """gRPC channel was closed unexpectedly."""

    def __init__(self, details: Optional[str] = None) -> None:
        super().__init__(
            "Connection to server was closed unexpectedly",
            code=ErrorCode.SERVICE_UNAVAILABLE,
            details=details,
        )


# ============================================================================
#  Authentication errors
# ============================================================================


class AuthenticationError(VectorAIError):
    """Base class for auth-related failures."""


class InvalidCredentialsError(AuthenticationError):
    """API key or credentials are invalid / expired."""

    def __init__(self, reason: str = "Invalid credentials") -> None:
        super().__init__(f"Authentication failed: {reason}", code=ErrorCode.UNAUTHORIZED)


class PermissionDeniedError(AuthenticationError):
    """Caller lacks permission for the requested operation."""

    def __init__(self, operation: str = "unknown") -> None:
        super().__init__(
            f"Permission denied for operation '{operation}'",
            code=ErrorCode.FORBIDDEN,
            operation=operation,
        )


# ============================================================================
#  Collection errors
# ============================================================================


class CollectionError(VectorAIError):
    """Base class for collection-related failures.

    Attributes:
        collection_name: The collection involved in the error.
    """

    def __init__(
        self,
        message: str,
        collection_name: str = "unknown",
        *,
        code: Optional[int] = None,
    ) -> None:
        super().__init__(message, code=code)
        self.collection_name = collection_name


class CollectionNotFoundError(CollectionError):
    """Collection does not exist."""

    def __init__(self, name: str) -> None:
        super().__init__(f"Collection '{name}' does not exist", name, code=ErrorCode.NOT_FOUND)


class CollectionExistsError(CollectionError):
    """Collection already exists."""

    def __init__(self, name: str) -> None:
        super().__init__(f"Collection '{name}' already exists", name, code=ErrorCode.CONFLICT)


class CollectionNotReadyError(CollectionError):
    """Collection is not in a ready state (loading, optimising, etc.)."""

    def __init__(self, name: str, reason: str = "") -> None:
        msg = f"Collection '{name}' is not ready"
        if reason:
            msg += f": {reason}"
        super().__init__(msg, name, code=ErrorCode.SERVICE_UNAVAILABLE)


# ============================================================================
#  Point / vector errors
# ============================================================================


class PointError(VectorAIError):
    """Base class for point / vector operation failures."""


class PointNotFoundError(PointError):
    """One or more point IDs were not found."""

    def __init__(self, ids: Any = "unknown", collection: str = "unknown") -> None:
        super().__init__(f"Point(s) {ids} not found in collection '{collection}'", code=ErrorCode.NOT_FOUND)
        self.ids = ids
        self.collection_name = collection


class DimensionMismatchError(PointError):
    """Vector dimension does not match the collection's expected dimension."""

    def __init__(self, expected: int, actual: int) -> None:
        super().__init__(
            f"Vector dimension mismatch: expected {expected}D, got {actual}D",
            code=ErrorCode.UNPROCESSABLE_ENTITY,
        )
        self.expected = expected
        self.actual = actual


# ============================================================================
#  Validation errors
# ============================================================================


class  ValidationError(VectorAIError):  # noqa: A001
    """Input failed client-side validation.

    Attributes:
        field: Optional name of the offending parameter.
    """

    def __init__(self, message: str, *, field: Optional[str] = None) -> None:
        super().__init__(message, code=ErrorCode.UNPROCESSABLE_ENTITY)
        self.field = field


# ============================================================================
#  Index errors
# ============================================================================


class IndexError(VectorAIError):  # noqa: A001
    """Index-related failure (build failed, not ready, etc.)."""

    def __init__(
        self,
        message: str,
        collection: str = "unknown",
        *,
        code: Optional[int] = None,
    ) -> None:
        super().__init__(message, code=code if code is not None else ErrorCode.INTERNAL_SERVER_ERROR)
        self.collection_name = collection


# ============================================================================
#  Server errors
# ============================================================================


class ServerError(VectorAIError):
    """Server-side error (INTERNAL, UNKNOWN, etc.)."""

    def __init__(self, message: str = "Internal server error", **kw: Any) -> None:
        super().__init__(f"Server error: {message}", code=kw.pop("code", ErrorCode.INTERNAL_SERVER_ERROR), **kw)


class UnimplementedError(ServerError):
    """Requested RPC is not implemented on the server."""

    def __init__(self, operation: str = "unknown") -> None:
        super().__init__(
            f"Operation '{operation}' is not implemented",
            code=ErrorCode.NOT_IMPLEMENTED,
            operation=operation,
        )


# ============================================================================
#  Timeout errors
# ============================================================================


class TimeoutError(VectorAIError):  # noqa: A001
    """Operation timed out or deadline was exceeded."""

    def __init__(self, operation: str = "request", timeout: float = 0) -> None:
        msg = f"Operation '{operation}' timed out"
        if timeout > 0:
            msg += f" after {timeout}s"
        super().__init__(msg, code=ErrorCode.REQUEST_TIMEOUT, operation=operation)
        self.timeout = timeout


# ============================================================================
#  Rate-limit errors
# ============================================================================


class RateLimitError(VectorAIError):
    """Rate limit or resource quota exceeded.

    Attributes:
        retry_after: Suggested seconds to wait before retrying (may be ``None``).
    """

    def __init__(self, retry_after: Optional[float] = None) -> None:
        if retry_after:
            msg = f"Rate limit exceeded. Retry after {retry_after}s"
        else:
            msg = "Server resource limit exceeded. Please retry later"
        super().__init__(msg, code=ErrorCode.TOO_MANY_REQUESTS)
        self.retry_after: Optional[float] = retry_after


# ============================================================================
#  Message size errors
# ============================================================================


class MessageSizeExceededError(VectorAIError):
    """gRPC message exceeds the maximum allowed size.

    Raised when a single RPC payload (e.g. a large batch upsert) is bigger
    than the server or client ``max_receive_message_length`` /
    ``max_send_message_length``.

    **Fix:**  Use ``client.upload_points()`` with a smaller ``batch_size``
    to automatically chunk large uploads into multiple RPC calls.

    Attributes:
        actual_size: Payload size in bytes (``None`` if not parsed).
        max_size:    Server limit in bytes (``None`` if not parsed).
    """

    def __init__(
        self,
        actual_size: Optional[int] = None,
        max_size: Optional[int] = None,
        *,
        details: Optional[str] = None,
    ) -> None:
        if actual_size is not None and max_size is not None:
            mb_actual = actual_size / (1024 * 1024)
            mb_max = max_size / (1024 * 1024)
            msg = (
                f"gRPC message size ({mb_actual:.1f} MB) exceeds server limit "
                f"({mb_max:.1f} MB). Use upload_points(collection, points, "
                f"batch_size=N) with a smaller batch_size to automatically "
                f"chunk large uploads."
            )
        else:
            msg = (
                "gRPC message size exceeds server limit. "
                "Use upload_points(collection, points, batch_size=N) with a "
                "smaller batch_size to automatically chunk large uploads."
            )
        super().__init__(msg, code=ErrorCode.TOO_MANY_REQUESTS, details=details)
        self.actual_size = actual_size
        self.max_size = max_size


# ============================================================================
#  Batch errors
# ============================================================================


class BatchError(VectorAIError):
    """A batch operation partially failed.

    Attributes:
        total:     Total number of operations attempted.
        failed:    Number of failed operations.
        succeeded: Number of successful operations.
        errors:    Per-item error details.
    """

    def __init__(
        self,
        total: int,
        failed: int,
        errors: Optional[list[Exception]] = None,
    ) -> None:
        super().__init__(f"{failed} of {total} operations failed")
        self.total = total
        self.failed = failed
        self.succeeded = total - failed
        self.errors = errors or []


# ============================================================================
#  Circuit breaker errors
# ============================================================================


class CircuitBreakerOpenError(VectorAIError):
    """Client-side circuit breaker is OPEN — not sending requests.

    Attributes:
        recovery_time: Seconds until half-open probe.
        failure_count: Consecutive failures that triggered open.
    """

    def __init__(self, recovery_time: float, failure_count: int) -> None:
        super().__init__(
            f"Circuit breaker open after {failure_count} failures. "
            f"Next probe in {recovery_time:.1f}s",
            code=ErrorCode.SERVICE_UNAVAILABLE,
        )
        self.recovery_time = recovery_time
        self.failure_count = failure_count


class MaxRetriesExceededError(VectorAIError):
    """All retry attempts exhausted.

    Attributes:
        attempts: Number of attempts made.
        last_error: The final error that caused the failure.
    """

    def __init__(self, attempts: int, last_error: Exception) -> None:
        super().__init__(
            f"Failed after {attempts} attempts",
            code=ErrorCode.SERVICE_UNAVAILABLE,
            operation=getattr(last_error, "operation", None),
        )
        self.attempts = attempts
        self.last_error = last_error


class ClientClosedError(VectorAIError):
    """Operation attempted on a closed client."""

    def __init__(self) -> None:
        super().__init__(
            "Client is closed. Create a new client instance.",
            code=ErrorCode.SERVICE_UNAVAILABLE,
        )


class PayloadError(VectorAIError):
    """Payload operation failed."""


class PayloadKeyNotFoundError(PayloadError):
    """Payload key does not exist."""

    def __init__(self, key: str, collection: str) -> None:
        super().__init__(
            f"Payload key '{key}' not found in collection '{collection}'",
            code=ErrorCode.NOT_FOUND,
        )
        self.key = key
        self.collection_name = collection


# ============================================================================
#  gRPC ↔ exception mapping
# ============================================================================


def from_grpc_error(
    error: Any,
    operation: Optional[str] = None,
    address: Optional[str] = None,
    collection_name: Optional[str] = None,
) -> VectorAIError:
    """Convert a gRPC ``RpcError`` to the appropriate :class:`VectorAIError`.

    Args:
        error: A ``grpc.RpcError`` instance.
        operation: Name of the RPC that failed (for context in the exception).

    Returns:
        The most specific ``VectorAIError`` sub-class for the gRPC status.
    """
    import grpc

    if not isinstance(error, grpc.RpcError):
        return VectorAIError(str(error), operation=operation)

    code = error.code()
    details: str = error.details() or ""

    # Extract trailing metadata for retry-after, etc.
    try:
        metadata: Dict[str, str] = dict(error.trailing_metadata() or [])
    except Exception as meta_exc:
        import logging as _logging

        _logging.getLogger("actian_vectorai.exceptions").warning(
            "Failed to extract gRPC trailing metadata: %s",
            meta_exc,
        )
        metadata = {}

    exc = _map_grpc_code(code, details, operation or "", metadata, address=address, collection_name=collection_name)
    exc.operation = operation

    return exc


# ============================================================================
#  VDE error code registry
# ============================================================================

# VDE error code -> exception class mapping (from cortex.core error_code.h)
_VDE_ERROR_REGISTRY: dict[int, type[VectorAIError]] = {
    100001: ServerError,  # UNKNOWN
    100002: ValidationError,  # INVALID_ARGUMENT
    100003: ServerError,  # NOT_INITIALIZED
    100004: ServerError,  # OUT_OF_MEMORY
    100101: ServerError,  # STORAGE_FILE_CREATE_FAILURE
    100200: IndexError,  # INDEX_INIT_FAILURE
    100201: IndexError,  # INDEX_ADD_FAILURE
    100202: IndexError,  # INDEX_SEARCH_FAILURE
    100203: IndexError,  # INDEX_BUILD_FAILURE
    100204: DimensionMismatchError,  # INVALID_DIMENSION
}


def _parse_vde_error_code(details: str) -> Optional[int]:
    """Extract VDE error code from gRPC details string."""
    import re

    match = re.search(r"VDE_ERROR_(\d+)", details)
    if match:
        return int(match.group(1))
    match = re.search(r"error_code[=:]\s*(\d{6})", details)
    if match:
        return int(match.group(1))
    return None


# ============================================================================
#  HTTP error mapping (for REST transport)
# ============================================================================


def from_http_error(
    status_code: int,
    body: Optional[str | dict[str, Any]] = None,
    headers: Optional[dict[str, str]] = None,
    operation: Optional[str] = None,
) -> VectorAIError:
    """Convert an HTTP error response to the appropriate VectorAIError.

    Mirrors :func:`from_grpc_error` for REST transport parity.
    """
    http_status_map: dict[int, type[VectorAIError]] = {
        ErrorCode.BAD_REQUEST:           ValidationError,
        ErrorCode.UNAUTHORIZED:          InvalidCredentialsError,
        ErrorCode.FORBIDDEN:             PermissionDeniedError,
        ErrorCode.NOT_FOUND:             CollectionNotFoundError,
        ErrorCode.REQUEST_TIMEOUT:       TimeoutError,
        ErrorCode.CONFLICT:              CollectionExistsError,
        ErrorCode.UNPROCESSABLE_ENTITY:  ValidationError,
        ErrorCode.TOO_MANY_REQUESTS:     RateLimitError,
        ErrorCode.INTERNAL_SERVER_ERROR: ServerError,
        ErrorCode.NOT_IMPLEMENTED:       UnimplementedError,
        ErrorCode.BAD_GATEWAY:           ConnectionError,
        ErrorCode.SERVICE_UNAVAILABLE:   ConnectionError,
        ErrorCode.GATEWAY_TIMEOUT:       TimeoutError,
    }

    detail_msg = _extract_http_error_message(body)

    exc_class = http_status_map.get(status_code, ServerError)

    exc: VectorAIError
    # Special handling for classes with non-standard constructors
    if exc_class == InvalidCredentialsError:
        exc = InvalidCredentialsError(detail_msg or "Authentication failed")
    elif exc_class == PermissionDeniedError:
        exc = PermissionDeniedError(operation or "unknown")
    elif exc_class == CollectionNotFoundError:
        exc = CollectionNotFoundError(_extract_name(detail_msg) if detail_msg else "unknown")
    elif exc_class == CollectionExistsError:
        exc = CollectionExistsError(_extract_name(detail_msg) if detail_msg else "unknown")
    elif exc_class == TimeoutError:
        exc = TimeoutError(operation or "request")
    elif exc_class == RateLimitError:
        retry_after = None
        if headers:
            raw = headers.get("retry-after")
            if raw:
                try:
                    retry_after = float(raw)
                except ValueError:
                    pass
        exc = RateLimitError(retry_after)
    elif exc_class == UnimplementedError:
        exc = UnimplementedError(operation or "unknown")
    elif exc_class == ConnectionError:
        exc = ConnectionError("Service unavailable", code=ErrorCode.SERVICE_UNAVAILABLE)
    elif exc_class == ValidationError:
        exc = ValidationError(detail_msg or "Bad request")
    else:
        exc = ServerError(detail_msg or f"HTTP {status_code}")

    exc.operation = operation
    return exc


def _map_grpc_code(
    code: Any,
    details: str,
    operation: str,
    metadata: Dict[str, str],
    address: Optional[str] = None,
    collection_name: Optional[str] = None,
) -> VectorAIError:
    """Dispatch a gRPC status code to the right exception factory."""
    import grpc

    dl = details.lower()

    if code == grpc.StatusCode.UNAUTHENTICATED:
        return InvalidCredentialsError(details or "Authentication failed")

    if code == grpc.StatusCode.PERMISSION_DENIED:
        return PermissionDeniedError(operation)

    if code == grpc.StatusCode.INVALID_ARGUMENT:
        if "dimension" in dl:
            expected, actual = _extract_dimensions(details)
            return DimensionMismatchError(expected, actual)
        return ValidationError(details or "Invalid argument")

    if code == grpc.StatusCode.DEADLINE_EXCEEDED:
        return TimeoutError(operation)

    if code == grpc.StatusCode.NOT_FOUND:
        if "collection" in dl:
            return CollectionNotFoundError(collection_name or _extract_name(details))
        return PointNotFoundError(details)

    if code == grpc.StatusCode.ALREADY_EXISTS:
        return CollectionExistsError(collection_name or _extract_name(details))

    if code == grpc.StatusCode.RESOURCE_EXHAUSTED:
        if "message larger than max" in dl or "sent message larger" in dl:
            actual, limit = _extract_message_sizes(details)  # type: ignore[assignment]
            return MessageSizeExceededError(actual, limit, details=details)
        return RateLimitError(_extract_retry_after(metadata))

    if code == grpc.StatusCode.UNAVAILABLE:
        addr = address or "unknown"
        if "refused" in dl:
            return ConnectionRefusedError(addr, details=details)
        if "timeout" in dl or "timed out" in dl:
            return ConnectionTimeoutError(addr, 0)
        if "closed" in dl:
            return ChannelClosedError(details)
        return ConnectionError("Server unavailable", code=ErrorCode.SERVICE_UNAVAILABLE)

    if code == grpc.StatusCode.UNIMPLEMENTED:
        return UnimplementedError(operation)

    if code == grpc.StatusCode.INTERNAL:
        # Map specific server error messages to appropriate exceptions
        if "not yet implemented" in dl or "not implemented" in dl:
            return UnimplementedError(operation)
        if "dimension" in dl:
            expected, actual = _extract_dimensions(details)
            return DimensionMismatchError(expected, actual)
        if "vector not found" in dl:
            return PointNotFoundError(details, collection=collection_name or "unknown")
        if "field index" in dl or "fieldindex" in dl:
            return IndexError(details, collection=collection_name or "unknown")
        if "collection" in dl and "not found" in dl:
            return CollectionNotFoundError(collection_name or _extract_name(details))
        # Parse VDE error codes from details
        vde_code = _parse_vde_error_code(details)
        if vde_code is not None:
            exc_cls = _VDE_ERROR_REGISTRY.get(vde_code, ServerError)
            if exc_cls == DimensionMismatchError:
                expected, actual = _extract_dimensions(details)
                return DimensionMismatchError(expected, actual)
            if exc_cls == IndexError:
                return IndexError(details, collection=collection_name or "unknown")
            if exc_cls == ValidationError:
                return ValidationError(details)
            return exc_cls(details) if exc_cls != ServerError else ServerError(details)
        return ServerError(details or "Internal error")

    if code == grpc.StatusCode.FAILED_PRECONDITION:
        if "collection" in dl and ("not ready" in dl or "not open" in dl or "not initialized" in dl):
            return CollectionNotReadyError(
                collection_name or _extract_name(details),
                reason=details,
            )
        return ServerError(details or "Precondition failed")

    if code == grpc.StatusCode.ABORTED:
        return ServerError(details or "Operation aborted")

    # CANCELLED, UNKNOWN, etc.
    return VectorAIError(
        details or "Unexpected server error",
        code=ErrorCode.INTERNAL_SERVER_ERROR,
        operation=operation,
    )


# ============================================================================
#  Retry helpers
# ============================================================================

_RETRYABLE_TYPES = (ConnectionError, RateLimitError, TimeoutError)
_RETRYABLE_CODES = frozenset({
    ErrorCode.SERVICE_UNAVAILABLE,
    ErrorCode.BAD_GATEWAY,
    ErrorCode.GATEWAY_TIMEOUT,
    ErrorCode.TOO_MANY_REQUESTS,
    ErrorCode.REQUEST_TIMEOUT,
})


def is_retryable(error: VectorAIError) -> bool:
    """Return ``True`` if *error* is a transient failure worth retrying."""
    # Message-size errors are deterministic — retrying the same payload
    # will always fail.  The user must reduce batch_size instead.
    if isinstance(error, MessageSizeExceededError):
        return False
    if isinstance(error, _RETRYABLE_TYPES):
        return True
    return error.code in _RETRYABLE_CODES if error.code is not None else False


def get_retry_delay(
    error: VectorAIError,
    attempt: int = 1,
    base_delay: float = 1.0,
    max_delay: float = 30.0,
) -> float:
    """Calculate retry delay with exponential back-off and jitter.

    Args:
        error:      The exception that triggered the retry.
        attempt:    Current retry attempt (1-based).
        base_delay: Initial delay in seconds.
        max_delay:  Maximum delay cap in seconds.

    Returns:
        Seconds to wait before the next retry.
    """
    if isinstance(error, RateLimitError) and error.retry_after:
        return float(error.retry_after)
    delay = base_delay * (2 ** (attempt - 1))
    jitter = random.uniform(0, 0.1 * delay)
    return min(delay + jitter, max_delay)  # type: ignore[no-any-return]


# ============================================================================
#  Private helpers
# ============================================================================


def _extract_name(details: str) -> str:
    """Try to pull a collection/entity name from an error message."""
    import re

    # Common server forms:
    #   Collection 'my_col' not found
    #   Collection not found: my_col
    #   collection=my_col
    patterns = (
        r"collection\s+not\s+found\s*:\s*([a-zA-Z0-9_.\-]+)",
        r"collection\s*[=:]\s*([a-zA-Z0-9_.\-]+)",
        r"collection\s+['\"]([^'\"]+)['\"]",
        r"['\"]([^'\"]+)['\"]",
    )
    for pattern in patterns:
        m = re.search(pattern, details, re.IGNORECASE)
        if m:
            return m.group(1)
    return "unknown"


def _extract_http_error_message(body: Optional[str | dict[str, Any]]) -> str:
    """Extract the most relevant message from HTTP error response payload."""
    if body is None:
        return ""
    if isinstance(body, str):
        return body
    if not isinstance(body, dict):
        return str(body)

    if isinstance(body.get("message"), str):
        return body["message"]  # type: ignore[no-any-return]
    if isinstance(body.get("error"), str):
        return body["error"]  # type: ignore[no-any-return]

    # Oatpp server format: {"status": {"error": "..."}, "time": ...}
    status = body.get("status")
    if isinstance(status, dict):
        if isinstance(status.get("error"), str):
            return status["error"]  # type: ignore[no-any-return]
        if isinstance(status.get("message"), str):
            return status["message"]  # type: ignore[no-any-return]

    return str(body)


def _extract_dimensions(details: str) -> tuple[int, int]:
    """Extract expected and actual dimensions from a server error message.

    Handles server messages like:
      ``"Dimension mismatch for 'default': expected 128, got 64"``
      ``"Sub-vector dimension mismatch for 'dense': expected 256, got 100"``
    """
    import re

    m = re.search(r"expected\s+(\d+).*?got\s+(\d+)", details, re.IGNORECASE)
    if m:
        return int(m.group(1)), int(m.group(2))
    return 0, 0


def _extract_retry_after(metadata: Dict[str, str]) -> Optional[float]:
    """Pull ``retry-after`` from gRPC trailing metadata."""
    raw_sec = metadata.get("retry-after")
    if raw_sec:
        try:
            return float(raw_sec)
        except ValueError:
            pass
    raw_ms = metadata.get("grpc-retry-after-ms")
    if raw_ms:
        try:
            return float(raw_ms) / 1000
        except ValueError:
            pass
    return None


def _extract_message_sizes(details: str) -> tuple[int | None, int | None]:
    """Extract actual and max message sizes from RESOURCE_EXHAUSTED details.

    Handles gRPC messages like:
      ``"Sent message larger than max (128000042 vs. 104857600)"``
      ``"Received message larger than max (128000042 vs 104857600)"``
    """
    import re

    m = re.search(r"(\d+)\s+vs\.?\s+(\d+)", details)
    if m:
        return int(m.group(1)), int(m.group(2))
    return None, None


# ============================================================================
#  Public API
# ============================================================================

__all__ = [
    # Error codes
    "ErrorCode",
    # Base
    "VectorAIError",
    # Connection
    "ConnectionError",
    "ConnectionRefusedError",
    "ConnectionTimeoutError",
    "ChannelClosedError",
    # Auth
    "AuthenticationError",
    "InvalidCredentialsError",
    "PermissionDeniedError",
    # Collection
    "CollectionError",
    "CollectionNotFoundError",
    "CollectionExistsError",
    "CollectionNotReadyError",
    # Point
    "PointError",
    "PointNotFoundError",
    "DimensionMismatchError",
    # Validation
    "ValidationError",
    # Index
    "IndexError",
    # Server
    "ServerError",
    "UnimplementedError",
    # Timeout / Rate-limit / Message-size / Batch
    "TimeoutError",
    "RateLimitError",
    "MessageSizeExceededError",
    "BatchError",
    # Resilience
    "CircuitBreakerOpenError",
    "MaxRetriesExceededError",
    "ClientClosedError",
    # Payload
    "PayloadError",
    "PayloadKeyNotFoundError",
    # Factories
    "from_grpc_error",
    "from_http_error",
    # Retry helpers
    "is_retryable",
    "get_retry_delay",
]
