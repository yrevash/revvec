############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Hybrid search fusion module.

Client-side implementations of Reciprocal Rank Fusion (RRF) and
Distribution-Based Score Fusion (DBSF) for combining results from
multiple heterogeneous retrieval pipelines.

While the server supports native fusion via the Universal Query API
(``Fusion.RRF`` / ``Fusion.DBSF`` in ``PrefetchQuery``), these
client-side helpers enable:

- Post-hoc fusion of results from separate queries
- Custom weighting per retrieval source
- Result deduplication across namespaces or named vectors

Reference: Cormack, Clarke & Buettcher (2009) — RRF
"""

from actian_vectorai.hybrid.fusion import (
    distribution_based_score_fusion,
    reciprocal_rank_fusion,
)

__all__ = [
    "reciprocal_rank_fusion",
    "distribution_based_score_fusion",
]
