############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Client-side score fusion algorithms for hybrid search pipelines.

Two algorithms are provided:

* **Reciprocal Rank Fusion (RRF)** — Rank-based fusion that ignores raw
  scores entirely.  Robust to score-scale differences between dense
  (cosine) and sparse (BM25) retrievers.

* **Distribution-Based Score Fusion (DBSF)** — Normalises scores from
  each retriever into the [0..1] range using mean ± 3σ, then averages.
  Preserves score magnitude information lost by RRF.

Both accept lists of ``ScoredPoint`` results from separate searches
and return a single, deduped, re-ranked list.

Usage::

    from actian_vectorai.hybrid import reciprocal_rank_fusion

    dense_results  = await client.points.search(col, vector=dense_vec, limit=50)
    sparse_results = await client.points.search(col, vector=sparse_vec, limit=50)

    fused = reciprocal_rank_fusion([dense_results, sparse_results], limit=10)
"""

from __future__ import annotations

import math
from collections import defaultdict
from typing import Any, Optional, Sequence

from actian_vectorai.models.points import ScoredPoint

# ============================================================================
#  Reciprocal Rank Fusion (RRF)
# ============================================================================


def reciprocal_rank_fusion(
    responses: Sequence[Sequence[ScoredPoint]],
    limit: int = 10,
    *,
    ranking_constant_k: int = 60,
    weights: Optional[Sequence[float]] = None,
) -> list[ScoredPoint]:
    """Fuse multiple ranked lists using Reciprocal Rank Fusion.

    .. math::

        \\text{RRF}(d) = \\sum_{r \\in R} \\frac{w_r}{k + \\text{rank}_r(d)}

    Args:
        responses: List of search result lists from different retrievers.
        limit: Maximum number of results to return.
        ranking_constant_k: Smoothing constant (default 60).  Lower
            values amplify the importance of top-ranked results.
        weights: Optional per-source weight multipliers.  Must have the
            same length as *responses*.  Defaults to uniform weighting.

    Returns:
        Merged and re-ranked list of ``ScoredPoint``, sorted by fused
        score descending, limited to *limit* items.
    """
    if not responses:
        return []

    n = len(responses)
    if weights is not None and len(weights) != n:
        raise ValueError(f"weights length ({len(weights)}) must match responses length ({n})")
    w = list(weights) if weights is not None else [1.0] * n

    # Accumulate RRF score per unique point ID
    scores: dict[Any, float] = defaultdict(float)
    best_point: dict[Any, ScoredPoint] = {}

    for source_idx, results in enumerate(responses):
        for rank, point in enumerate(results, start=1):
            pid = _point_key(point)
            scores[pid] += w[source_idx] / (ranking_constant_k + rank)
            # Keep the version of the point with the highest original score
            if pid not in best_point or (
                point.score is not None
                and (best_point[pid].score is None or point.score > best_point[pid].score)
            ):
                best_point[pid] = point

    # Build result list sorted by fused score
    ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)[:limit]
    result = []
    for pid, fused_score in ranked:
        pt = best_point[pid]
        result.append(
            ScoredPoint(
                id=pt.id,
                version=pt.version,
                score=fused_score,
                payload=pt.payload,
                vectors=pt.vectors,
            )
        )
    return result


# ============================================================================
#  Distribution-Based Score Fusion (DBSF)
# ============================================================================


def distribution_based_score_fusion(
    responses: Sequence[Sequence[ScoredPoint]],
    limit: int = 10,
) -> list[ScoredPoint]:
    """Fuse multiple ranked lists using Distribution-Based Score Fusion.

    Each source's scores are normalised into [0, 1] using:

    .. math::

        \\hat{s} = \\frac{s - (\\mu - 3\\sigma)}{(\\mu + 3\\sigma) - (\\mu - 3\\sigma)}

    Then the normalised scores are averaged across all sources that
    contain the same point.

    Args:
        responses: List of search result lists from different retrievers.
        limit: Maximum number of results to return.

    Returns:
        Merged, normalised, and re-ranked ``ScoredPoint`` list.
    """
    if not responses:
        return []

    # ── Phase 1: normalise each source ────────────────────────────
    normalised_scores: dict[Any, list[float]] = defaultdict(list)
    best_point: dict[Any, ScoredPoint] = {}

    for results in responses:
        raw_scores = [p.score for p in results if p.score is not None]
        if not raw_scores:
            continue

        mu = _mean(raw_scores)
        sigma = _std(raw_scores, mu)

        lower = mu - 3 * sigma
        upper = mu + 3 * sigma
        span = upper - lower if upper != lower else 1.0

        for point in results:
            pid = _point_key(point)
            s = point.score if point.score is not None else 0.0
            normalised = max(0.0, min(1.0, (s - lower) / span))
            normalised_scores[pid].append(normalised)

            if pid not in best_point or (
                point.score is not None
                and (best_point[pid].score is None or point.score > best_point[pid].score)
            ):
                best_point[pid] = point

    # ── Phase 2: average and rank ─────────────────────────────────
    fused: dict[Any, float] = {}
    for pid, norm_list in normalised_scores.items():
        fused[pid] = sum(norm_list) / len(norm_list)

    ranked = sorted(fused.items(), key=lambda kv: kv[1], reverse=True)[:limit]
    result = []
    for pid, fused_score in ranked:
        pt = best_point[pid]
        result.append(
            ScoredPoint(
                id=pt.id,
                version=pt.version,
                score=fused_score,
                payload=pt.payload,
                vectors=pt.vectors,
            )
        )
    return result


# ============================================================================
#  Private helpers
# ============================================================================


def _point_key(point: ScoredPoint) -> Any:
    """Hashable key for a scored point (supports int and UUID-string IDs)."""
    return point.id


def _mean(values: list[float]) -> float:
    return sum(values) / len(values)


def _std(values: list[float], mu: float) -> float:
    if len(values) < 2:
        return 0.0
    var = sum((v - mu) ** 2 for v in values) / len(values)
    return math.sqrt(var)
