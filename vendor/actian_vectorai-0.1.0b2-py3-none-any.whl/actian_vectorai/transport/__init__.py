############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Transport sub-package — connection pooling, TLS, gRPC interceptors, and REST."""

from actian_vectorai.transport.interceptors import (
    AuthInterceptor,
    CircuitBreakerInterceptor,
    LoggingInterceptor,
    MetadataInterceptor,
    RetryInterceptor,
    TracingInterceptor,
    UserAgentInterceptor,
)
from actian_vectorai.transport.pool import (
    ConnectionPool,
    PoolConfig,
    create_credentials_from_files,
    create_ssl_credentials,
)
from actian_vectorai.transport.rest import RESTTransport

__all__ = [
    # Pool
    "ConnectionPool",
    "PoolConfig",
    # TLS
    "create_ssl_credentials",
    "create_credentials_from_files",
    # Interceptors
    "AuthInterceptor",
    "RetryInterceptor",
    "TracingInterceptor",
    "LoggingInterceptor",
    "MetadataInterceptor",
    "UserAgentInterceptor",
    "CircuitBreakerInterceptor",
    # REST
    "RESTTransport",
]
