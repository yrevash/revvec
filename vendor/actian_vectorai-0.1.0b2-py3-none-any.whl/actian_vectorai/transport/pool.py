############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Connection pool and TLS credential helpers.

:class:`ConnectionPool` manages a configurable number of ``grpc.aio``
channels to the same server endpoint, rotating requests across them via
round-robin to bypass the HTTP/2 ``MAX_CONCURRENT_STREAMS`` limit.

Example::

    pool = ConnectionPool("localhost:50051", config=PoolConfig(pool_size=4))
    await pool.connect()
    channel = pool.get_channel()        # round-robin
    stub = SomeServiceStub(channel)
    await stub.SomeMethod(request)
    await pool.close()
"""

from __future__ import annotations

import asyncio
import logging
import threading
from dataclasses import dataclass
from typing import Any, Optional, Sequence

import grpc
import grpc.aio

logger = logging.getLogger(__name__)


# ============================================================================
#  TLS / SSL helpers
# ============================================================================


def create_ssl_credentials(
    root_certificates: Optional[bytes] = None,
    private_key: Optional[bytes] = None,
    certificate_chain: Optional[bytes] = None,
) -> grpc.ChannelCredentials:
    """Create SSL/TLS channel credentials.

    Args:
        root_certificates: PEM-encoded root CA certificate for server
            verification.  If ``None``, the system default trust store is used.
        private_key: PEM-encoded client private key for mutual TLS.
        certificate_chain: PEM-encoded client certificate for mutual TLS.

    Returns:
        Channel credentials suitable for :func:`grpc.aio.secure_channel`.
    """
    return grpc.ssl_channel_credentials(
        root_certificates=root_certificates,
        private_key=private_key,
        certificate_chain=certificate_chain,
    )


def create_credentials_from_files(
    ca_cert_path: Optional[str] = None,
    client_key_path: Optional[str] = None,
    client_cert_path: Optional[str] = None,
) -> grpc.ChannelCredentials:
    """Convenience wrapper that reads PEM files and returns credentials.

    Args:
        ca_cert_path: Path to the CA certificate file.
        client_key_path: Path to the client private key file (mutual TLS).
        client_cert_path: Path to the client certificate file (mutual TLS).

    Returns:
        Channel credentials suitable for :func:`grpc.aio.secure_channel`.
    """

    def _read(path: Optional[str]) -> Optional[bytes]:
        if path is None:
            return None
        with open(path, "rb") as fh:
            return fh.read()

    return create_ssl_credentials(
        root_certificates=_read(ca_cert_path),
        private_key=_read(client_key_path),
        certificate_chain=_read(client_cert_path),
    )


# ============================================================================
#  Pool configuration
# ============================================================================


@dataclass(frozen=True, slots=True)
class PoolConfig:
    """Tuning knobs for the connection pool.

    Attributes:
        pool_size: Number of gRPC channels to keep open.
        keepalive_time_ms: Interval between keepalive pings (ms).
        keepalive_timeout_ms: Timeout for keepalive response (ms).
        max_message_length: Max send/receive message size in bytes.
        enable_retries: Enable gRPC-level automatic retry policy.
        connect_timeout: Seconds to wait for initial connectivity.
    """

    pool_size: int = 3
    keepalive_time_ms: int = 30_000
    keepalive_timeout_ms: int = 10_000
    max_message_length: int = 100 * 1024 * 1024  # 100 MiB
    enable_retries: bool = True
    connect_timeout: float = 30.0


# ============================================================================
#  Per-channel state
# ============================================================================


@dataclass
class _ChannelState:
    """Internal bookkeeping for a single pooled channel."""

    channel: grpc.aio.Channel
    request_count: int = 0
    is_healthy: bool = True
    last_error: Optional[Exception] = None


# ============================================================================
#  Async connection pool
# ============================================================================


class ConnectionPool:
    """Async connection pool managing multiple ``grpc.aio.Channel`` instances.

    Uses round-robin distribution to spread requests across channels,
    effectively multiplying concurrent stream capacity.

    Supports ``async with`` as a context manager::

        async with ConnectionPool("localhost:50051") as pool:
            channel = pool.get_channel()
            ...
    """

    __slots__ = (
        "_address",
        "_config",
        "_credentials",
        "_interceptors",
        "_channels",
        "_idx",
        "_idx_lock",
        "_closed",
    )

    def __init__(
        self,
        address: str,
        config: Optional[PoolConfig] = None,
        credentials: Optional[grpc.ChannelCredentials] = None,
        interceptors: Optional[Sequence[grpc.aio.ClientInterceptor]] = None,
    ) -> None:
        self._address = address
        self._config = config or PoolConfig()
        self._credentials = credentials
        self._interceptors = list(interceptors) if interceptors else []
        self._channels: list[_ChannelState] = []
        self._idx = 0
        self._idx_lock = threading.Lock()
        self._closed = False

    # -- Context manager ----------------------------------------------------

    async def __aenter__(self) -> ConnectionPool:
        await self.connect()
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.close()

    # -- Lifecycle ----------------------------------------------------------

    async def connect(self) -> None:
        """Create *pool_size* channels (idempotent)."""
        if self._channels:
            return

        cfg = self._config
        options = [
            ("grpc.keepalive_time_ms", cfg.keepalive_time_ms),
            ("grpc.keepalive_timeout_ms", cfg.keepalive_timeout_ms),
            ("grpc.keepalive_permit_without_calls", True),
            ("grpc.max_receive_message_length", cfg.max_message_length),
            ("grpc.max_send_message_length", cfg.max_message_length),
            ("grpc.enable_retries", int(cfg.enable_retries)),
        ]

        for i in range(cfg.pool_size):
            ch = self._make_channel(options)
            self._channels.append(_ChannelState(channel=ch))
            logger.debug("Created channel %d/%d to %s", i + 1, cfg.pool_size, self._address)

        self._closed = False
        logger.info(
            "Connection pool ready — %d channel(s) to %s",
            cfg.pool_size,
            self._address,
        )

    async def close(self) -> None:
        """Close all channels (idempotent)."""
        if self._closed:
            return
        self._closed = True
        for st in self._channels:
            try:
                await st.channel.close()
            except Exception as exc:
                logger.warning("Error closing channel: %s", exc)
        self._channels.clear()
        logger.info("Connection pool closed")

    # -- Channel access -----------------------------------------------------

    def get_channel(self) -> grpc.aio.Channel:
        """Return the next channel via round-robin.

        Raises:
            ConnectionError: If the pool has been closed or never connected.
        """
        if self._closed or not self._channels:
            from actian_vectorai.exceptions import ConnectionError as ConnErr

            raise ConnErr("Pool is closed or not connected", code=14)

        with self._idx_lock:
            idx = self._idx
            self._idx = (idx + 1) % len(self._channels)
            self._channels[idx].request_count += 1
        return self._channels[idx].channel

    # -- Health / stats -----------------------------------------------------

    @property
    def is_connected(self) -> bool:
        """``True`` if the pool has open channels."""
        return bool(self._channels) and not self._closed

    @property
    def size(self) -> int:
        """Number of channels in the pool."""
        return len(self._channels)

    @property
    def address(self) -> str:
        return self._address

    async def wait_for_ready(self, timeout: Optional[float] = None) -> bool:
        """Wait until at least one channel is READY.

        Args:
            timeout: Maximum seconds to wait (default: ``connect_timeout``).

        Returns:
            ``True`` if a channel became ready, ``False`` on timeout.
        """
        if not self._channels:
            return False
        t = timeout if timeout is not None else self._config.connect_timeout
        try:
            done, _ = await asyncio.wait(
                [asyncio.ensure_future(st.channel.channel_ready()) for st in self._channels],
                timeout=t,
                return_when=asyncio.FIRST_COMPLETED,
            )
            return len(done) > 0
        except asyncio.TimeoutError:
            return False

    async def health_check(self, timeout: float = 5.0) -> bool:
        """Probe every channel and update ``is_healthy`` flags.

        Returns:
            ``True`` if at least one channel is healthy.
        """
        if self._closed or not self._channels:
            return False

        healthy = 0
        for st in self._channels:
            try:
                st.channel.get_state(try_to_connect=True)
                await asyncio.wait_for(st.channel.channel_ready(), timeout=timeout)
                st.is_healthy = True
                st.last_error = None
                healthy += 1
            except Exception as exc:
                st.is_healthy = False
                st.last_error = exc
                logger.warning("Channel health-check failed: %s", exc)

        logger.debug("Health check: %d/%d healthy", healthy, len(self._channels))
        return healthy > 0

    def get_stats(self) -> dict[str, Any]:
        """Return pool statistics for monitoring dashboards."""
        return {
            "address": self._address,
            "pool_size": len(self._channels),
            "is_connected": self.is_connected,
            "channels": [
                {
                    "index": i,
                    "requests": st.request_count,
                    "healthy": st.is_healthy,
                }
                for i, st in enumerate(self._channels)
            ],
        }

    # -- Private helpers ----------------------------------------------------

    def _make_channel(self, options: list[tuple[str, Any]]) -> grpc.aio.Channel:
        if self._credentials:
            return grpc.aio.secure_channel(
                self._address,
                self._credentials,
                options=options,
                interceptors=self._interceptors,
            )
        return grpc.aio.insecure_channel(
            self._address,
            options=options,
            interceptors=self._interceptors,
        )
