############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Filter DSL subpackage — Type-safe filter builder for search queries.

Fluent builder that compiles directly to protobuf Filter objects.
"""

from actian_vectorai.filters.dsl import (
    Field,
    FilterBuilder,
    has_id,
    has_vector,
    is_empty,
    is_null,
    nested,
)

# Re-export Condition and Filter from models for convenience.
from actian_vectorai.models.common import Condition, Filter

__all__ = [
    # Builder API
    "Field",
    "FilterBuilder",
    # Standalone condition factories
    "has_id",
    "has_vector",
    "is_empty",
    "is_null",
    "nested",
    # Model re-exports
    "Condition",
    "Filter",
]
