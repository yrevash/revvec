############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""VDE namespace — async methods for the CollectionsExt gRPC service.

Implemented:
  - Lifecycle: open_collection, close_collection
  - Persistence: save_snapshot, load_snapshot
  - Status: get_state, get_vector_count, get_stats, get_optimizations
  - Maintenance: flush, rebuild_index, optimize
  - Rebuild management: trigger_rebuild, get_rebuild_task,
    list_rebuild_tasks, cancel_rebuild_task
  - Advanced: compact_collection
"""

from __future__ import annotations

import logging

from actian_vectorai._executor import grpc_call
from actian_vectorai.models.enums import (
    CollectionState,
    RebuildTaskState,
)
from actian_vectorai.models.vde import (
    CollectionStats,
    CompactOptions,
    CompactStats,
    OptimizationsResponse,
    RebuildDataSourceConfig,
    RebuildRunConfig,
    RebuildStats,
    RebuildTargetConfig,
    RebuildTaskInfo,
)
from actian_vectorai.proto import actian_vectorai_collections_ext_pb2 as ext_pb
from actian_vectorai.proto import actian_vectorai_collections_ext_pb2_grpc as ext_grpc

__all__ = ["VDENamespace"]

logger = logging.getLogger("actian_vectorai.vde")


# ─── Namespace ────────────────────────────────────────────────────────


class VDENamespace:
    """Async operations on the ``CollectionsExt`` gRPC service (VDE extensions).

    Instantiated by ``AsyncVectorAIClient`` — not created directly.
    """

    __slots__ = ("_stub", "_timeout")

    def __init__(
        self,
        stub: ext_grpc.CollectionsExtStub,
        *,
        timeout: float | None = None,
    ) -> None:
        self._stub = stub
        self._timeout = timeout

    # ═══════════════════════════════════════════════════════════
    #  Lifecycle
    # ═══════════════════════════════════════════════════════════

    async def open_collection(
        self,
        name: str,
        *,
        timeout: float | None = None,
    ) -> bool:
        """Open a collection for read/write operations.

        Some operations (e.g. ``get_vector_count``) require the
        collection to be explicitly opened first.

        Returns
        -------
        ``True`` on success.
        """
        req = ext_pb.OpenCollectionRequest(collection_name=name)
        resp = await grpc_call(
            self._stub.OpenCollection,
            req,
            timeout=timeout if timeout is not None else self._timeout,
        )
        logger.debug("Opened collection %r (%.3fs)", name, resp.time)
        return resp.result

    async def close_collection(
        self,
        name: str,
        *,
        timeout: float | None = None,
    ) -> bool:
        """Close a collection, releasing server-side resources.

        Returns
        -------
        ``True`` on success.
        """
        req = ext_pb.CloseCollectionRequest(collection_name=name)
        resp = await grpc_call(
            self._stub.CloseCollection,
            req,
            timeout=timeout if timeout is not None else self._timeout,
        )
        logger.debug("Closed collection %r (%.3fs)", name, resp.time)
        return resp.result

    # ═══════════════════════════════════════════════════════════
    #  Persistence
    # ═══════════════════════════════════════════════════════════

    async def save_snapshot(
        self,
        name: str,
        *,
        timeout: float | None = None,
    ) -> bool:
        """Save a persistence snapshot of the collection.

        Returns
        -------
        ``True`` on success.
        """
        req = ext_pb.VdeSaveSnapshotRequest(collection_name=name)
        resp = await grpc_call(
            self._stub.SaveSnapshot,
            req,
            timeout=timeout if timeout is not None else self._timeout,
        )
        logger.debug("Saved snapshot for %r (%.3fs)", name, resp.time)
        return resp.result

    async def load_snapshot(
        self,
        name: str,
        *,
        timeout: float | None = None,
    ) -> bool:
        """Load a collection from its latest snapshot.

        Returns
        -------
        ``True`` on success.
        """
        req = ext_pb.VdeLoadSnapshotRequest(collection_name=name)
        resp = await grpc_call(
            self._stub.LoadSnapshot,
            req,
            timeout=timeout if timeout is not None else self._timeout,
        )
        logger.debug("Loaded snapshot for %r (%.3fs)", name, resp.time)
        return resp.result

    # ═══════════════════════════════════════════════════════════
    #  Status & Statistics
    # ═══════════════════════════════════════════════════════════

    async def get_state(
        self,
        name: str,
        *,
        timeout: float | None = None,
    ) -> CollectionState:
        """Get the current state of a collection (READY, REBUILDING, ERROR).

        Returns
        -------
        ``CollectionState`` enum value.
        """
        req = ext_pb.GetStateRequest(collection_name=name)
        resp = await grpc_call(
            self._stub.GetState,
            req,
            timeout=timeout if timeout is not None else self._timeout,
        )
        return CollectionState(resp.state)

    async def get_vector_count(
        self,
        name: str,
        *,
        timeout: float | None = None,
    ) -> int:
        """Get the total vector count in a collection.

        Returns
        -------
        Number of vectors.
        """
        req = ext_pb.GetVectorCountRequest(collection_name=name)
        resp = await grpc_call(
            self._stub.GetVectorCount,
            req,
            timeout=timeout if timeout is not None else self._timeout,
        )
        return resp.count

    async def get_stats(
        self,
        name: str,
        *,
        timeout: float | None = None,
    ) -> CollectionStats:
        """Get detailed collection statistics.

        Returns
        -------
        ``CollectionStats`` with vector counts, storage bytes, etc.
        """
        req = ext_pb.GetStatsRequest(collection_name=name)
        resp = await grpc_call(
            self._stub.GetStats,
            req,
            timeout=timeout if timeout is not None else self._timeout,
        )
        return CollectionStats.from_proto(resp.stats)

    async def get_optimizations(
        self,
        name: str,
        *,
        include_completed: bool | None = None,
        completed_limit: int | None = None,
        timeout: float | None = None,
    ) -> OptimizationsResponse:
        """Get ongoing and completed optimization operations.

        Parameters
        ----------
        include_completed:
            Whether to include completed optimizations.
        completed_limit:
            Maximum number of completed operations to return.

        Returns
        -------
        ``OptimizationsResponse`` with ongoing and completed lists.
        """
        req = ext_pb.GetOptimizationsRequest(collection_name=name)
        if include_completed is not None:
            req.include_completed = include_completed
        if completed_limit is not None:
            req.completed_limit = completed_limit

        resp = await grpc_call(
            self._stub.GetOptimizations,
            req,
            timeout=timeout if timeout is not None else self._timeout,
        )
        return OptimizationsResponse.from_proto(resp.optimizations)

    # ═══════════════════════════════════════════════════════════
    #  Maintenance
    # ═══════════════════════════════════════════════════════════

    async def flush(
        self,
        name: str,
        *,
        timeout: float | None = None,
    ) -> bool:
        """Flush pending writes to persistent storage.

        Returns
        -------
        ``True`` on success.
        """
        req = ext_pb.FlushRequest(collection_name=name)
        resp = await grpc_call(
            self._stub.Flush,
            req,
            timeout=timeout if timeout is not None else self._timeout,
        )
        logger.debug("Flushed %r (%.3fs)", name, resp.time)
        return resp.result

    async def rebuild_index(
        self,
        name: str,
        *,
        timeout: float | None = None,
    ) -> bool:
        """Trigger a simple index rebuild.

        For advanced rebuild control, use ``trigger_rebuild()`` instead.

        Returns
        -------
        ``True`` on success.
        """
        req = ext_pb.RebuildIndexRequest(collection_name=name)
        resp = await grpc_call(
            self._stub.RebuildIndex,
            req,
            timeout=timeout if timeout is not None else self._timeout,
        )
        logger.debug("Rebuild index for %r (%.3fs)", name, resp.time)
        return resp.result

    async def optimize(
        self,
        name: str,
        *,
        timeout: float | None = None,
    ) -> bool:
        """Trigger collection optimization (merge segments, etc.).

        Returns
        -------
        ``True`` on success.
        """
        req = ext_pb.OptimizeRequest(collection_name=name)
        resp = await grpc_call(
            self._stub.Optimize,
            req,
            timeout=timeout if timeout is not None else self._timeout,
        )
        logger.debug("Optimized %r (%.3fs)", name, resp.time)
        return resp.result

    # ═══════════════════════════════════════════════════════════
    #  Rebuild Management
    # ═══════════════════════════════════════════════════════════

    async def trigger_rebuild(
        self,
        name: str,
        *,
        source: RebuildDataSourceConfig | None = None,
        target: RebuildTargetConfig | None = None,
        run_config: RebuildRunConfig | None = None,
        wait: bool | None = None,
        wait_timeout: int | None = None,
        priority: int | None = None,
        timeout: float | None = None,
    ) -> tuple[str, RebuildStats | None]:
        """Trigger an advanced rebuild with full configuration.

        Parameters
        ----------
        source:
            Data source configuration (current index, storage, snapshot, etc.).
        target:
            Target index configuration (HNSW, IVF, etc.).
        run_config:
            Run parameters (batch size, catchup rounds, etc.).
        wait:
            Block until rebuild completes.
        wait_timeout:
            Timeout in seconds when waiting.
        priority:
            Higher priority tasks execute first.

        Returns
        -------
        Tuple of (task_id, optional RebuildStats if wait=True).
        """
        req = ext_pb.TriggerRebuildRequest(collection_name=name)
        if source is not None:
            req.source.CopyFrom(source.to_proto())
        if target is not None:
            req.target.CopyFrom(target.to_proto())
        if run_config is not None:
            req.run_config.CopyFrom(run_config.to_proto())
        if wait is not None:
            req.wait = wait
        if wait_timeout is not None:
            req.timeout = wait_timeout
        if priority is not None:
            req.priority = priority

        resp = await grpc_call(
            self._stub.TriggerRebuild,
            req,
            timeout=timeout if timeout is not None else self._timeout,
        )
        stats = RebuildStats.from_proto(resp.stats) if resp.HasField("stats") else None
        logger.debug(
            "Triggered rebuild for %r → task %s (%.3fs)",
            name,
            resp.task_id,
            resp.time,
        )
        return resp.task_id, stats

    async def get_rebuild_task(
        self,
        task_id: str,
        *,
        timeout: float | None = None,
    ) -> RebuildTaskInfo:
        """Get the status of a rebuild task.

        Returns
        -------
        ``RebuildTaskInfo`` with progress, state, and stats.
        """
        req = ext_pb.GetRebuildTaskRequest(task_id=task_id)
        resp = await grpc_call(
            self._stub.GetRebuildTask,
            req,
            timeout=timeout if timeout is not None else self._timeout,
        )
        return RebuildTaskInfo.from_proto(resp.task)

    async def list_rebuild_tasks(
        self,
        *,
        collection_name: str | None = None,
        state: RebuildTaskState | None = None,
        limit: int | None = None,
        offset: int | None = None,
        timeout: float | None = None,
    ) -> tuple[list[RebuildTaskInfo], int]:
        """List rebuild tasks with optional filtering.

        Returns
        -------
        Tuple of (tasks, total_count).
        """
        req = ext_pb.ListRebuildTasksRequest()
        if collection_name is not None:
            req.collection_name = collection_name
        if state is not None:
            req.state = state
        if limit is not None:
            req.limit = limit
        if offset is not None:
            req.offset = offset

        resp = await grpc_call(
            self._stub.ListRebuildTasks,
            req,
            timeout=timeout if timeout is not None else self._timeout,
        )
        tasks = [RebuildTaskInfo.from_proto(t) for t in resp.tasks]
        return tasks, resp.total_count

    async def cancel_rebuild_task(
        self,
        task_id: str,
        *,
        timeout: float | None = None,
    ) -> bool:
        """Cancel a running rebuild task.

        Returns
        -------
        ``True`` on success.
        """
        req = ext_pb.CancelRebuildTaskRequest(task_id=task_id)
        resp = await grpc_call(
            self._stub.CancelRebuildTask,
            req,
            timeout=timeout if timeout is not None else self._timeout,
        )
        logger.debug("Cancelled rebuild task %s", task_id)
        return resp.result

    # ═══════════════════════════════════════════════════════════
    #  Advanced Operations
    # ═══════════════════════════════════════════════════════════

    async def compact_collection(
        self,
        name: str,
        *,
        options: CompactOptions | None = None,
        wait: bool | None = None,
        wait_timeout: int | None = None,
        timeout: float | None = None,
    ) -> tuple[str, CompactStats | None]:
        """Compact a collection (merge segments, purge deleted vectors).

        Parameters
        ----------
        options:
            Compact parameters (target segments, force merge, purge, etc.).
        wait:
            Block until compaction completes.

        Returns
        -------
        Tuple of (task_id, optional CompactStats if wait=True).
        """
        req = ext_pb.CompactCollectionRequest(collection_name=name)
        if options is not None:
            req.options.CopyFrom(options.to_proto())
        if wait is not None:
            req.wait = wait
        if wait_timeout is not None:
            req.timeout = wait_timeout

        resp = await grpc_call(
            self._stub.CompactCollection,
            req,
            timeout=timeout if timeout is not None else self._timeout,
        )
        stats = CompactStats.from_proto(resp.stats) if resp.HasField("stats") else None
        logger.debug("Compacted %r, task %s (%.3fs)", name, resp.task_id, resp.time)
        return resp.task_id, stats

    def __repr__(self) -> str:
        return "VDENamespace()"
