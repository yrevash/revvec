############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Structured JSON logging for enterprise log aggregators.

Provides a custom formatter that outputs JSON lines compatible with
Datadog, Splunk, ELK stack, and other enterprise logging platforms.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone

__all__ = ["StructuredJsonFormatter", "configure_structured_logging"]


class StructuredJsonFormatter(logging.Formatter):
    """JSON log formatter for structured logging.

    Output format::

        {"ts": "2026-03-11T...", "level": "INFO",
         "logger": "actian_vectorai.client",
         "msg": "Connected to localhost:50051", ...}
    """

    # Extra fields to extract from LogRecord if present
    _EXTRA_FIELDS = (
        "operation",
        "collection",
        "duration_ms",
        "request_id",
        "status",
        "transport",
    )

    def format(self, record: logging.LogRecord) -> str:
        log_entry: dict[str, object] = {
            "ts": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        for key in self._EXTRA_FIELDS:
            val = getattr(record, key, None)
            if val is not None:
                log_entry[key] = val
        if record.exc_info and record.exc_info[1]:
            log_entry["error"] = str(record.exc_info[1])
            log_entry["error_type"] = type(record.exc_info[1]).__name__
        return json.dumps(log_entry, default=str)


def configure_structured_logging(
    level: int = logging.INFO,
    logger_name: str = "actian_vectorai",
) -> logging.Logger:
    """Configure the ``actian_vectorai`` logger with structured JSON output.

    Parameters
    ----------
    level:
        Logging level (default: ``logging.INFO``).
    logger_name:
        Logger name to configure (default: ``"actian_vectorai"``).

    Returns
    -------
    The configured :class:`logging.Logger` instance.
    """
    logger = logging.getLogger(logger_name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(StructuredJsonFormatter())
        logger.addHandler(handler)
    logger.setLevel(level)
    return logger
