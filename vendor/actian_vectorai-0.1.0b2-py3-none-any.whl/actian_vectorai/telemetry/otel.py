############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""OpenTelemetry integration for distributed tracing and metrics.

This module is opt-in: requires ``actian-vectorai[telemetry]``.
If opentelemetry packages are not installed, all operations are no-ops.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Generator

__all__ = ["trace_operation", "record_request"]

# Lazy-loaded tracers and meters — no crash if OTel is absent.
_tracer: Any = None
_meter: Any = None


class _NoOpSpan:
    """Minimal no-op span for when OTel is not installed."""

    def set_attribute(self, key: str, value: Any) -> None:
        pass

    def set_status(self, *args: Any, **kwargs: Any) -> None:
        pass

    def record_exception(self, exc: BaseException) -> None:
        pass

    def __enter__(self) -> _NoOpSpan:
        return self

    def __exit__(self, *exc: Any) -> None:
        pass


class _NoOpTracer:
    """Minimal no-op tracer for when OTel is not installed."""

    def start_as_current_span(self, name: str, **kwargs: Any) -> _NoOpSpan:
        return _NoOpSpan()


class _NoOpCounter:
    def add(self, amount: int, attributes: dict[str, Any] | None = None) -> None:
        pass


class _NoOpHistogram:
    def record(self, value: float, attributes: dict[str, Any] | None = None) -> None:
        pass


class _NoOpMeter:
    def create_counter(self, name: str, **kwargs: Any) -> _NoOpCounter:
        return _NoOpCounter()

    def create_histogram(self, name: str, **kwargs: Any) -> _NoOpHistogram:
        return _NoOpHistogram()


def _get_tracer() -> Any:
    global _tracer
    if _tracer is None:
        try:
            from opentelemetry import trace

            _tracer = trace.get_tracer("actian_vectorai", "0.1.0")
        except ImportError:
            _tracer = _NoOpTracer()
    return _tracer


def _get_meter() -> Any:
    global _meter
    if _meter is None:
        try:
            from opentelemetry import metrics

            _meter = metrics.get_meter("actian_vectorai", "0.1.0")
        except ImportError:
            _meter = _NoOpMeter()
    return _meter


@contextmanager
def trace_operation(
    operation: str,
    collection: str | None = None,
    **attrs: Any,
) -> Generator[Any, None, None]:
    """Context manager that creates an OTel span for an SDK operation.

    Usage::

        with trace_operation("search", collection="my_col", limit=10):
            result = await stub.Search(req)
    """
    tracer = _get_tracer()
    span_attrs: dict[str, Any] = {
        "db.system": "actian_vectorai",
        "db.operation": operation,
    }
    if collection:
        span_attrs["db.collection"] = collection
    span_attrs.update(attrs)

    with tracer.start_as_current_span(f"actian.{operation}", attributes=span_attrs) as span:
        yield span


# ── Metrics ───────────────────────────────────────────────────────

_request_counter: Any = None
_request_duration: Any = None
_error_counter: Any = None


def record_request(operation: str, duration_ms: float, success: bool) -> None:
    """Record a request metric (counter + duration histogram).

    Parameters
    ----------
    operation:
        RPC or REST method name.
    duration_ms:
        Request duration in milliseconds.
    success:
        Whether the request succeeded.
    """
    global _request_counter, _request_duration, _error_counter
    meter = _get_meter()

    if _request_counter is None:
        _request_counter = meter.create_counter(
            "actian.client.requests",
            description="Total SDK requests",
        )
        _request_duration = meter.create_histogram(
            "actian.client.request.duration_ms",
            description="Request duration in milliseconds",
        )
        _error_counter = meter.create_counter(
            "actian.client.errors",
            description="Total SDK errors",
        )

    attrs = {"operation": operation}
    _request_counter.add(1, attrs)
    _request_duration.record(duration_ms, attrs)
    if not success:
        _error_counter.add(1, attrs)
