############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Collections namespace — async methods for the Collections gRPC service.

Implemented RPCs: Create, Get, List, Delete, CollectionExists, Update.

Usage (via the client)::

    async with AsyncVectorAIClient("localhost:50051") as client:
        await client.collections.create(
            "my_col",
            vectors_config=VectorParams(size=128, distance=Distance.Cosine),
        )
        info = await client.collections.get_info("my_col")
        names = await client.collections.list()
        await client.collections.delete("my_col")
"""

from __future__ import annotations

import builtins
import logging
from dataclasses import dataclass
from typing import Any

from actian_vectorai._executor import grpc_call
from actian_vectorai.models.collections import (
    CollectionInfo,
    HnswConfigDiff,
    OptimizersConfigDiff,
    QuantizationConfig,
    QuantizationConfigDiff,
    VectorParams,
    VectorParamsDiff,
    WalConfigDiff,
)
from actian_vectorai.models.enums import (
    IndexType,
    ShardingMethod,
)
from actian_vectorai.proto import actian_vectorai_collections_pb2 as col_pb
from actian_vectorai.proto import actian_vectorai_collections_service_pb2_grpc as col_grpc

__all__ = ["CollectionsNamespace"]

logger = logging.getLogger("actian_vectorai.collections")


# ─── Stub container injected by the client ────────────────────────────


@dataclass
class _Stubs:
    """gRPC stubs used by this namespace (injected by the client)."""

    collections: col_grpc.CollectionsStub


# ─── Helpers ──────────────────────────────────────────────────────────


def _build_vectors_config(
    vectors_config: VectorParams | dict[str, VectorParams] | None,
) -> col_pb.VectorsConfig | None:
    """Build the oneof VectorsConfig proto from user input."""
    if vectors_config is None:
        return None
    cfg = col_pb.VectorsConfig()
    if isinstance(vectors_config, VectorParams):
        cfg.params.CopyFrom(vectors_config.to_proto())
    elif isinstance(vectors_config, dict):
        params_map = col_pb.VectorParamsMap()
        for name, vp in vectors_config.items():
            params_map.map[name].CopyFrom(vp.to_proto())
        cfg.params_map.CopyFrom(params_map)
    return cfg


def _build_vectors_config_diff(
    vectors_config: dict[str, VectorParamsDiff] | None,
) -> col_pb.VectorsConfigDiff | None:
    """Build the VectorsConfigDiff proto for update."""
    if vectors_config is None:
        return None
    cfg = col_pb.VectorsConfigDiff()
    for name, vp in vectors_config.items():
        cfg.params_map.map[name].CopyFrom(vp.to_proto())
    return cfg


def _build_sparse_config(
    sparse_vectors_config: dict[str, Any] | None,
) -> col_pb.SparseVectorConfig | None:
    """Build SparseVectorConfig from a name→SparseVectorParams dict."""
    if not sparse_vectors_config:
        return None
    cfg = col_pb.SparseVectorConfig()
    for name, params in sparse_vectors_config.items():
        if not hasattr(params, "to_proto"):
            from actian_vectorai.exceptions import ValidationError
            raise ValidationError(
                f"Sparse vector params for {name!r} must have a to_proto() method, "
                f"got {type(params).__name__}",
                field="sparse_vectors_config",
            )
        cfg.map[name].CopyFrom(params.to_proto())
    return cfg


# ─── Namespace ────────────────────────────────────────────────────────


class CollectionsNamespace:
    """Async operations on the ``Collections`` gRPC service.

    Instantiated by ``AsyncVectorAIClient`` — not created directly.
    """

    __slots__ = ("_stub", "_timeout")

    def __init__(
        self,
        stub: col_grpc.CollectionsStub,
        *,
        timeout: float | None = None,
    ) -> None:
        self._stub = stub
        self._timeout = timeout

    # ── CRUD ────────────────────────────────────────────────────

    async def create(
        self,
        name: str,
        *,
        vectors_config: VectorParams | dict[str, VectorParams] | None = None,
        hnsw_config: HnswConfigDiff | None = None,
        wal_config: WalConfigDiff | None = None,
        optimizers_config: OptimizersConfigDiff | None = None,
        quantization_config: QuantizationConfig | None = None,
        sparse_vectors_config: dict[str, Any] | None = None,
        shard_number: int | None = None,
        on_disk_payload: bool | None = None,
        replication_factor: int | None = None,
        write_consistency_factor: int | None = None,
        sharding_method: ShardingMethod | None = None,
        timeout: float | None = None,
        # VDE extensions
        index_type: IndexType | None = None,
        ivf_config: Any | None = None,
        extra_params_json: str | None = None,
    ) -> bool:
        """Create a new collection.

        Parameters
        ----------
        name:
            Collection name.
        vectors_config:
            Dense vector configuration. A single ``VectorParams`` for
            the default (unnamed) vector, or a ``dict[str, VectorParams]``
            for named vectors.
        hnsw_config:
            HNSW index parameters.
        optimizers_config:
            Optimizer parameters.
        quantization_config:
            Quantization parameters.
        timeout:
            Per-call timeout (seconds).
        index_type:
            VDE index type (FLAT, HNSW, IVF_FLAT, …).
        ivf_config:
            VDE IVF configuration.

        Returns
        -------
        ``True`` on success.

        Raises
        ------
        CollectionExistsError
            If a collection with ``name`` already exists.
        ValidationError
            If ``name`` fails collection-name validation rules.
        """
        from actian_vectorai.exceptions import ValidationError
        from actian_vectorai.utils.validation import validate_collection_name

        try:
            validate_collection_name(name)
        except ValidationError as e:
            e.field = "name"
            raise

        req = col_pb.CreateCollection(collection_name=name)

        vcfg = _build_vectors_config(vectors_config)
        if vcfg is not None:
            req.vectors_config.CopyFrom(vcfg)
        if hnsw_config is not None:
            req.hnsw_config.CopyFrom(hnsw_config.to_proto())
        if wal_config is not None:
            req.wal_config.CopyFrom(wal_config.to_proto())
        if optimizers_config is not None:
            req.optimizers_config.CopyFrom(optimizers_config.to_proto())
        if quantization_config is not None:
            req.quantization_config.CopyFrom(quantization_config.to_proto())
        sparse_cfg = _build_sparse_config(sparse_vectors_config)
        if sparse_cfg is not None:
            req.sparse_vectors_config.CopyFrom(sparse_cfg)
        if shard_number is not None:
            req.shard_number = shard_number
        if on_disk_payload is not None:
            req.on_disk_payload = on_disk_payload
        if replication_factor is not None:
            req.replication_factor = replication_factor
        if write_consistency_factor is not None:
            req.write_consistency_factor = write_consistency_factor
        if sharding_method is not None:
            req.sharding_method = sharding_method
        # VDE extensions (100+)
        if index_type is not None:
            req.index_type = index_type
        if ivf_config is not None:
            if hasattr(ivf_config, "to_proto"):
                req.ivf_config.CopyFrom(ivf_config.to_proto())
        if extra_params_json is not None:
            req.extra_params_json = extra_params_json

        resp = await grpc_call(
            self._stub.Create,
            req,
            timeout=timeout if timeout is not None else self._timeout,
            collection_name=name,
        )
        logger.debug("Created collection %r (%.3fs)", name, resp.time)
        return resp.result

    async def get_info(self, name: str, *, timeout: float | None = None) -> CollectionInfo:
        """Get detailed information about a collection.

        Parameters
        ----------
        name:
            Collection name.

        Returns
        -------
        ``CollectionInfo`` with config, status, schema, counts.
        """
        req = col_pb.GetCollectionInfoRequest(collection_name=name)
        resp = await grpc_call(
            self._stub.Get,
            req,
            timeout=timeout if timeout is not None else self._timeout,
            collection_name=name,
        )
        return CollectionInfo.from_proto(resp.result)

    async def list(self, *, timeout: float | None = None) -> builtins.list[str]:
        """List all collection names.

        Returns
        -------
        Sorted list of collection name strings.
        """
        req = col_pb.ListCollectionsRequest()
        resp = await grpc_call(
            self._stub.List,
            req,
            timeout=timeout if timeout is not None else self._timeout,
        )
        return sorted(c.name for c in resp.collections)

    async def delete(
        self,
        name: str,
        *,
        strict: bool = True,
        timeout: float | None = None,
    ) -> bool:
        """Delete a collection and all associated data.

        Parameters
        ----------
        name:
            Collection name.
        strict:
            When ``True`` (default), raises ``CollectionNotFoundError`` if
            the collection does not exist.  When ``False``, returns ``False``
            instead.

        Returns
        -------
        ``True`` on success.

        Raises
        ------
        CollectionNotFoundError
            If ``strict=True`` and the collection does not exist.
        """
        req = col_pb.DeleteCollection(collection_name=name)
        resp = await grpc_call(
            self._stub.Delete,
            req,
            timeout=timeout if timeout is not None else self._timeout,
            collection_name=name,
        )
        logger.debug("Deleted collection %r (%.3fs)", name, resp.time)
        if strict and not resp.result:
            from actian_vectorai.exceptions import CollectionNotFoundError
            raise CollectionNotFoundError(collection_name=name)
        return resp.result

    async def exists(self, name: str, *, timeout: float | None = None) -> bool:
        """Check whether a collection exists.

        Returns
        -------
        ``True`` if the collection exists.

        Raises
        ------
        ValidationError
            If ``name`` fails collection-name validation rules.
        """
        from actian_vectorai.exceptions import ValidationError
        from actian_vectorai.utils.validation import validate_collection_name

        try:
            validate_collection_name(name)
        except ValidationError as e:
            e.field = "name"
            raise

        req = col_pb.CollectionExistsRequest(collection_name=name)
        resp = await grpc_call(
            self._stub.CollectionExists,
            req,
            timeout=timeout if timeout is not None else self._timeout,
            collection_name=name,
        )
        return resp.result.exists

    async def update(
        self,
        name: str,
        *,
        optimizers_config: OptimizersConfigDiff | None = None,
        hnsw_config: HnswConfigDiff | None = None,
        vectors_config: dict[str, VectorParamsDiff] | None = None,
        quantization_config: QuantizationConfigDiff | None = None,
        sparse_vectors_config: dict[str, Any] | None = None,
        timeout: float | None = None,
        # VDE extensions
        ivf_config: Any | None = None,
        vde_timeout: int | None = None,
    ) -> bool:
        """Update collection parameters.

        Only provided parameters are changed; others remain untouched.

        Returns
        -------
        ``True`` on success.
        """
        req = col_pb.UpdateCollection(collection_name=name)
        if optimizers_config is not None:
            req.optimizers_config.CopyFrom(optimizers_config.to_proto())
        if hnsw_config is not None:
            req.hnsw_config.CopyFrom(hnsw_config.to_proto())
        vcfg = _build_vectors_config_diff(vectors_config)
        if vcfg is not None:
            req.vectors_config.CopyFrom(vcfg)
        if quantization_config is not None:
            req.quantization_config.CopyFrom(quantization_config.to_proto())
        sparse_cfg = _build_sparse_config(sparse_vectors_config)
        if sparse_cfg is not None:
            req.sparse_vectors_config.CopyFrom(sparse_cfg)
        if ivf_config is not None and hasattr(ivf_config, "to_proto"):
            req.ivf_config.CopyFrom(ivf_config.to_proto())
        if vde_timeout is not None:
            req.vde_timeout = vde_timeout

        resp = await grpc_call(
            self._stub.Update,
            req,
            timeout=timeout if timeout is not None else self._timeout,
            collection_name=name,
        )
        logger.debug("Updated collection %r (%.3fs)", name, resp.time)
        return resp.result

    # ── Convenience ──────────────────────────────────────────────

    async def recreate(
        self,
        name: str,
        *,
        vectors_config: VectorParams | dict[str, VectorParams] | None = None,
        timeout: float | None = None,
        **kwargs: Any,
    ) -> bool:
        """Drop (if exists) and re-create a collection.

        Accepts all the same keyword arguments as ``create()``.
        """
        if await self.exists(name, timeout=timeout):
            await self.delete(name, timeout=timeout)
        return await self.create(
            name,
            vectors_config=vectors_config,
            timeout=timeout,
            **kwargs,
        )

    async def get_or_create(
        self,
        name: str,
        *,
        vectors_config: VectorParams | dict[str, VectorParams] | None = None,
        timeout: float | None = None,
        **kwargs: Any,
    ) -> CollectionInfo:
        """Get a collection if it exists, or create it.

        Returns
        -------
        ``CollectionInfo`` for the (possibly new) collection.
        """
        if not await self.exists(name, timeout=timeout):
            await self.create(
                name,
                vectors_config=vectors_config,
                timeout=timeout,
                **kwargs,
            )
        return await self.get_info(name, timeout=timeout)

    def __repr__(self) -> str:
        return "CollectionsNamespace()"
