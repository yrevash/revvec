############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""VectorAIClient — synchronous client for Actian VectorAI DB.

A zero-duplication sync wrapper around ``AsyncVectorAIClient``.
Every async namespace method is transparently bridged through a
background ``asyncio`` event-loop thread — the caller never needs
to ``await`` anything.

Usage::

    with VectorAIClient("localhost:50051") as client:
        client.collections.create(
            "my_col",
            vectors_config=VectorParams(size=128, distance=Distance.Cosine),
        )
        client.points.upsert("my_col", points=[...])
        results = client.points.search("my_col", vector=[...], limit=10)
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from actian_vectorai._executor import BackgroundLoop, SyncProxy
from actian_vectorai.async_client import AsyncVectorAIClient

if TYPE_CHECKING:
    from actian_vectorai._collections import CollectionsNamespace
    from actian_vectorai._points import PointsNamespace
    from actian_vectorai._vde import VDENamespace

__all__ = ["VectorAIClient"]

logger = logging.getLogger("actian_vectorai.client")


class VectorAIClient:
    """Synchronous client for Actian VectorAI DB.

    Mirrors the full ``AsyncVectorAIClient`` API without requiring
    ``async`` / ``await``.  Internally delegates to an async client
    running on a background event-loop thread.

    Parameters
    ----------
    url:
        gRPC server address (``host:port``).
    api_key:
        Optional API key for authentication.
    tls:
        Enable TLS.
    tls_ca_cert:
        Path to CA certificate file.
    timeout:
        Default per-RPC timeout in seconds.
    max_message_size:
        Maximum gRPC message size in bytes (default: 256 MiB).
    max_retries:
        Maximum retry attempts for transient gRPC errors.
    enable_tracing:
        Inject ``x-request-id`` / ``x-request-timestamp`` headers.
    enable_logging:
        Log every RPC call timing.
    metadata:
        Static metadata injected into every RPC call.
    grpc_options:
        Additional raw gRPC channel options.

    Example
    -------
    ::

        client = VectorAIClient("localhost:50051")
        client.connect()

        client.collections.create("test", vectors_config=VectorParams(size=4, distance=Distance.Cosine))
        client.points.upsert("test", [PointStruct(id=1, vector=[0.1, 0.2, 0.3, 0.4])])
        results = client.points.search("test", vector=[0.1, 0.2, 0.3, 0.4], limit=5)

        client.close()

    Or using a context manager::

        with VectorAIClient("localhost:50051") as client:
            ...
    """

    def __init__(self, url: str = "localhost:50051", **kwargs: Any) -> None:
        self._loop = BackgroundLoop()
        self._async_client = AsyncVectorAIClient(url, **kwargs)
        self._collections: SyncProxy | None = None
        self._points: SyncProxy | None = None
        self._vde: SyncProxy | None = None

    # ── Properties ────────────────────────────────────────────────

    @property
    def collections(self) -> CollectionsNamespace:
        """Collections namespace (create, delete, list, info, …)."""
        if self._collections is None:
            self._collections = SyncProxy(
                self._async_client.collections,
                self._loop,
            )
        return self._collections  # type: ignore[return-value]

    @property
    def points(self) -> PointsNamespace:
        """Points namespace (upsert, search, query, scroll, …)."""
        if self._points is None:
            self._points = SyncProxy(
                self._async_client.points,
                self._loop,
            )
        return self._points  # type: ignore[return-value]

    @property
    def vde(self) -> VDENamespace:
        """VDE extensions namespace (rebuild, compact, stats, …)."""
        if self._vde is None:
            self._vde = SyncProxy(
                self._async_client.vde,
                self._loop,
            )
        return self._vde  # type: ignore[return-value]

    @property
    def is_connected(self) -> bool:
        """Whether the client is connected to the server."""
        return self._async_client.is_connected

    # ── Connection lifecycle ──────────────────────────────────────

    def connect(self) -> None:
        """Establish the gRPC channel and create service stubs."""
        self._loop.run(self._async_client.connect())
        # Reset cached proxies so they pick up the new stubs
        self._collections = None
        self._points = None
        self._vde = None

    def close(self) -> None:
        """Close the gRPC channel and release resources."""
        self._loop.run(self._async_client.close())
        self._collections = None
        self._points = None
        self._vde = None

    def shutdown(self) -> None:
        """Close the client and stop the background event loop.

        After ``shutdown()``, this client instance cannot be reused.
        """
        self.close()
        self._loop.close()

    # ── Context manager ───────────────────────────────────────────

    def __enter__(self) -> VectorAIClient:
        self.connect()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.shutdown()

    # ── Top-level convenience ─────────────────────────────────────

    def health_check(self, *, timeout: float | None = None) -> dict[str, Any]:
        """Check server health (sync)."""
        return self._loop.run(
            self._async_client.health_check(timeout=timeout),
        )

    def upload_points(
        self,
        collection_name: str,
        points: list,
        *,
        batch_size: int = 256,
    ) -> int:
        """Upload points with automatic batching (sync).

        See :meth:`AsyncVectorAIClient.upload_points` for details.
        """
        return self._loop.run(
            self._async_client.upload_points(
                collection_name,
                points,
                batch_size=batch_size,
            ),
        )

    def __repr__(self) -> str:
        status = "connected" if self.is_connected else "disconnected"
        return f"VectorAIClient(url={self._async_client._config.url!r}, {status})"

    def __del__(self) -> None:
        # Best-effort cleanup — avoid accessing complex state during GC.
        try:
            if hasattr(self, "_loop") and not self._loop.loop.is_closed():
                self._loop.close()
        except Exception:
            pass
