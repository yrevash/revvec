############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Validation utilities for VectorAI DB client operations.

Provides input validation for vectors, collection names, and payloads
to prevent server errors and provide clear error messages.
"""

from __future__ import annotations

import re
import uuid
from typing import Any, Optional, Sequence, Union

import numpy as np

from actian_vectorai.exceptions import ValidationError


def validate_collection_name(name: str) -> str:
    """Validate collection name.

    Args:
        name: Collection name to validate

    Returns:
        The validated collection name

    Raises:
        ValidationError: If name is invalid

    Note:
        Collection names must:
        - Be 1-64 characters
        - Contain only alphanumeric characters, underscores, and hyphens
        - Start with a letter, digit, or underscore
    """
    if not isinstance(name, str):
        raise ValidationError(f"Collection name must be a string, got {type(name).__name__!r}")

    if not name:
        raise ValidationError("Collection name cannot be empty")

    if len(name) > 64:
        raise ValidationError(f"Collection name too long: {len(name)} > 64 characters")

    # Must start with letter, digit, or underscore, end with alphanumeric or underscore
    # (not hyphen), and contain only alphanumeric characters, underscores, or hyphens.
    pattern = r"^[a-zA-Z0-9_]([a-zA-Z0-9_-]*[a-zA-Z0-9_])?$"
    if not re.match(pattern, name):
        raise ValidationError(
            f"Invalid collection name '{name}'. Must start with a letter, digit, or underscore, "
            "end with a letter, digit, or underscore, "
            "and contain only alphanumeric characters, underscores, or hyphens."
        )

    return name


def validate_vector(
    vector: Union[list[float], "np.ndarray[Any, Any]", Any],
    expected_dimension: Optional[int] = None,
    name: str = "vector",
) -> list[float]:
    """Validate vector data.

    Args:
        vector: Vector to validate
        expected_dimension: Expected dimension (if known from collection)
        name: Name for error messages

    Returns:
        The vector as a list of floats

    Raises:
        ValidationError: If vector is invalid
    """
    # Convert numpy array to list
    if isinstance(vector, np.ndarray):
        vector = vector.tolist()

    if not isinstance(vector, (list, tuple)):
        raise ValidationError(f"{name} must be a list or numpy array, got {type(vector).__name__}")

    if len(vector) == 0:
        raise ValidationError(f"{name} cannot be empty")

    # Check all elements are numeric
    for i, v in enumerate(vector):
        if not isinstance(v, (int, float)):
            raise ValidationError(f"{name}[{i}] must be numeric, got {type(v).__name__}")

    # Check dimension if specified
    if expected_dimension is not None and len(vector) != expected_dimension:
        raise ValidationError(
            f"{name} dimension mismatch: got {len(vector)}, expected {expected_dimension}"
        )

    return list(float(v) for v in vector)


def validate_vectors_batch(
    vectors: Sequence[Union[list[float], "np.ndarray[Any, Any]"]],
    expected_dimension: Optional[int] = None,
) -> list[list[float]]:
    """Validate a batch of vectors.

    Args:
        vectors: List of vectors to validate
        expected_dimension: Expected dimension (if known from collection)

    Returns:
        List of validated vectors

    Raises:
        ValidationError: If any vector is invalid
    """
    if not vectors:
        raise ValidationError("Vectors list cannot be empty")

    validated = []
    dimension = expected_dimension

    for i, vec in enumerate(vectors):
        validated_vec = validate_vector(vec, dimension, f"vector[{i}]")
        validated.append(validated_vec)

        # Infer dimension from first vector if not specified
        if dimension is None:
            dimension = len(validated_vec)

    return validated


def validate_payload(payload: Optional[dict[str, Any]]) -> Optional[dict[str, Any]]:
    """Validate payload dictionary.

    Args:
        payload: Payload to validate

    Returns:
        The validated payload

    Raises:
        ValidationError: If payload is invalid
    """
    if payload is None:
        return None

    if not isinstance(payload, dict):
        raise ValidationError(f"Payload must be a dict, got {type(payload).__name__}")

    # Check keys are strings
    for key in payload.keys():
        if not isinstance(key, str):
            raise ValidationError(f"Payload keys must be strings, got {type(key).__name__}")

    return payload


def validate_id(id_val: Union[int, str, uuid.UUID]) -> Union[int, str]:
    """Validate a single vector ID (non-negative int, UUID string, or uuid.UUID object).

    Args:
        id_val: ID to validate — non-negative int, valid UUID string, or uuid.UUID object.
                uuid.UUID objects are automatically converted to their canonical string form.

    Returns:
        Validated ID

    Raises:
        ValidationError: If the ID is invalid
    """
    if isinstance(id_val, uuid.UUID):
        # Accept uuid.UUID objects directly — convert to canonical string form
        return str(id_val)
    if isinstance(id_val, int):
        if id_val < 0:
            raise ValidationError(f"ID must be non-negative, got {id_val}")
        return id_val
    if isinstance(id_val, str):
        try:
            uuid.UUID(id_val)
        except ValueError:
            raise ValidationError(f"String ID must be a valid UUID, got '{id_val}'") from None
        return id_val
    raise ValidationError(
        f"ID must be a non-negative integer or UUID string, got {type(id_val).__name__}"
    )


def validate_ids(ids: Sequence[Union[int, str, uuid.UUID]]) -> list[Union[int, str]]:
    """Validate a list of vector IDs (non-negative ints, UUID strings, or uuid.UUID objects).

    Args:
        ids: List of IDs to validate

    Returns:
        List of validated IDs

    Raises:
        ValidationError: If any ID is invalid
    """
    if not ids:
        raise ValidationError("IDs list cannot be empty")

    validated = []
    for i, id_val in enumerate(ids):
        try:
            validated.append(validate_id(id_val))
        except ValidationError as e:
            raise ValidationError(f"IDs[{i}]: {e}") from e

    return validated


_MAX_SEARCH_LIMIT: int = 1_000_000


def validate_top_k(top_k: int) -> int:
    """Validate top_k / limit parameter for search operations.

    Args:
        top_k: Number of results to return.

    Returns:
        Validated top_k value

    Raises:
        ValidationError: If top_k is invalid
    """
    if not isinstance(top_k, int):
        raise ValidationError(f"limit must be an integer, got {type(top_k).__name__}")

    if top_k < 1:
        raise ValidationError(f"limit must be >= 1, got {top_k}")

    if top_k > _MAX_SEARCH_LIMIT:
        raise ValidationError(f"limit {top_k} exceeds maximum allowed value of {_MAX_SEARCH_LIMIT}")

    return top_k


def validate_batch_size(batch_size: int, *, max_size: int = 10_000) -> int:
    """Validate batch size parameter.

    Args:
        batch_size: Batch size to validate.
        max_size: Maximum allowed batch size.

    Returns:
        Validated batch size.

    Raises:
        ValidationError: If batch_size is invalid.
    """
    if not isinstance(batch_size, int) or batch_size < 1:
        raise ValidationError(f"batch_size must be a positive integer, got {batch_size}")
    if batch_size > max_size:
        raise ValidationError(f"batch_size {batch_size} exceeds max {max_size}")
    return batch_size


def validate_timeout(timeout: Optional[float]) -> Optional[float]:
    """Validate timeout parameter.

    Args:
        timeout: Timeout value in seconds.

    Returns:
        Validated timeout value.

    Raises:
        ValidationError: If timeout is invalid.
    """
    if timeout is None:
        return None
    if not isinstance(timeout, (int, float)) or timeout <= 0:
        raise ValidationError(f"timeout must be a positive number, got {timeout}")
    return float(timeout)


def validate_vector_dimension(dimension: int) -> int:
    """Validate vector dimension parameter.

    Args:
        dimension: Dimension to validate.

    Returns:
        Validated dimension.

    Raises:
        ValidationError: If dimension is invalid.
    """
    if not isinstance(dimension, int) or dimension < 1:
        raise ValidationError(f"Vector dimension must be a positive integer, got {dimension}")
    if dimension > 65536:
        raise ValidationError(f"Vector dimension {dimension} exceeds maximum (65536)")
    return dimension


def validate_sparse_vector(values: Sequence[float], indices: Sequence[int]) -> None:
    """Validate sparse vector components.

    Args:
        values: Sparse vector values.
        indices: Sparse vector indices.

    Raises:
        ValidationError: If sparse vector is invalid.
    """
    if len(values) != len(indices):
        raise ValidationError(
            f"Sparse vector length mismatch: {len(values)} values vs {len(indices)} indices"
        )
    if indices and min(indices) < 0:
        raise ValidationError("Sparse vector indices must be non-negative")
    if len(set(indices)) != len(indices):
        raise ValidationError("Sparse vector indices must be unique")


def validate_payload_keys(keys: Sequence[str]) -> list[str]:
    """Validate payload key names.

    Args:
        keys: List of payload keys to validate.

    Returns:
        Validated list of keys.

    Raises:
        ValidationError: If any key is invalid.
    """
    if not keys:
        raise ValidationError("Payload keys list cannot be empty")
    for i, key in enumerate(keys):
        if not isinstance(key, str):
            raise ValidationError(f"Payload key[{i}] must be a string, got {type(key).__name__}")
        if not key:
            raise ValidationError(f"Payload key[{i}] cannot be empty")
    return list(keys)
