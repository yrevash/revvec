############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Internal utilities for the Actian VectorAI Python SDK."""

from actian_vectorai.utils.validation import (
    validate_collection_name,
    validate_vector_dimension,
)

__all__ = [
    "validate_collection_name",
    "validate_vector_dimension",
]
