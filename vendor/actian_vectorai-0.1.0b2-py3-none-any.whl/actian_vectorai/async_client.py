############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""AsyncVectorAIClient — the primary async client for Actian VectorAI DB.

Manages gRPC connections and exposes namespace-based API:
  - ``client.collections.*``  → Collection CRUD, aliases, shards
  - ``client.points.*``       → Data CRUD, search, query, payload
  - ``client.vde.*``          → VDE extensions (rebuild, compact, …)
  - ``client.health_check()`` → Server health

Usage::

    async with AsyncVectorAIClient("localhost:50051") as client:
        await client.collections.create(
            "my_col",
            vectors_config=VectorParams(size=128, distance=Distance.Cosine),
        )
        await client.points.upsert("my_col", points=[...])
        results = await client.points.search("my_col", vector=[...], limit=10)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

import grpc
import grpc.aio

from actian_vectorai._collections import CollectionsNamespace
from actian_vectorai._executor import grpc_call
from actian_vectorai._points import PointsNamespace
from actian_vectorai._vde import VDENamespace
from actian_vectorai.exceptions import ConnectionError as VaiConnectionError
from actian_vectorai.exceptions import ErrorCode
from actian_vectorai.proto import (
    actian_vectorai_collections_ext_pb2_grpc as ext_grpc,
)
from actian_vectorai.proto import (
    actian_vectorai_collections_service_pb2_grpc as col_grpc,
)
from actian_vectorai.proto import (
    actian_vectorai_pb2 as vectorai_pb,
)
from actian_vectorai.proto import (
    actian_vectorai_pb2_grpc as vectorai_grpc,
)
from actian_vectorai.proto import (
    actian_vectorai_points_service_pb2_grpc as pts_grpc,
)
from actian_vectorai.transport import (
    AuthInterceptor,
    ConnectionPool,
    LoggingInterceptor,
    MetadataInterceptor,
    PoolConfig,
    RetryInterceptor,
    TracingInterceptor,
    UserAgentInterceptor,
    create_credentials_from_files,
)

__all__ = ["AsyncVectorAIClient"]

logger = logging.getLogger("actian_vectorai.client")

# Sensible default for channel max receive message size (256 MiB)
_DEFAULT_MAX_MESSAGE: int = 256 * 1024 * 1024


# ─── Client Config ────────────────────────────────────────────────────


@dataclass(frozen=True)
class ClientConfig:
    """Immutable configuration for the client."""

    url: str = "localhost:50051"
    api_key: str | None = None
    tls: bool = False
    tls_ca_cert: str | None = None
    tls_client_cert: str | None = None
    tls_client_key: str | None = None
    timeout: float | None = 30.0
    max_message_size: int = _DEFAULT_MAX_MESSAGE
    max_retries: int = 3
    pool_size: int = 1
    enable_tracing: bool = True
    enable_logging: bool = False
    metadata: dict[str, str] = field(default_factory=dict)
    grpc_options: list[tuple[str, Any]] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.url:
            raise ValueError("url must not be empty")
        if self.timeout is not None and self.timeout <= 0:
            raise ValueError(f"timeout must be positive, got {self.timeout}")
        if self.max_message_size <= 0:
            raise ValueError(f"max_message_size must be positive, got {self.max_message_size}")
        if self.max_retries < 0:
            raise ValueError(f"max_retries must be >= 0, got {self.max_retries}")
        if self.pool_size < 1:
            raise ValueError(f"pool_size must be >= 1, got {self.pool_size}")


# ─── Async Client ─────────────────────────────────────────────────────


class AsyncVectorAIClient:
    """Async client for Actian VectorAI DB.

    Parameters
    ----------
    url:
        gRPC server address (``host:port``).
    api_key:
        Optional API key for authentication.
    tls:
        Enable TLS (auto-detected if port is 443).
    tls_ca_cert:
        Path to CA certificate file.
    timeout:
        Default per-RPC timeout in seconds.
    max_message_size:
        Maximum gRPC message size in bytes (default: 256 MiB).
    max_retries:
        Maximum retry attempts for transient gRPC errors.
    enable_tracing:
        Inject ``x-request-id`` / ``x-request-timestamp`` headers.
    enable_logging:
        Log every RPC call timing.
    metadata:
        Static metadata injected into every RPC call.
    grpc_options:
        Additional raw gRPC channel options.
    """

    def __init__(
        self,
        url: str = "localhost:50051",
        *,
        api_key: str | None = None,
        tls: bool = False,
        tls_ca_cert: str | None = None,
        tls_client_cert: str | None = None,
        tls_client_key: str | None = None,
        timeout: float | None = 30.0,
        max_message_size: int = _DEFAULT_MAX_MESSAGE,
        max_retries: int = 3,
        pool_size: int = 1,
        enable_tracing: bool = True,
        enable_logging: bool = False,
        metadata: dict[str, str] | None = None,
        grpc_options: list[tuple[str, Any]] | None = None,
    ) -> None:
        self._config = ClientConfig(
            url=url,
            api_key=api_key,
            tls=tls,
            tls_ca_cert=tls_ca_cert,
            tls_client_cert=tls_client_cert,
            tls_client_key=tls_client_key,
            timeout=timeout,
            max_message_size=max_message_size,
            max_retries=max_retries,
            pool_size=pool_size,
            enable_tracing=enable_tracing,
            enable_logging=enable_logging,
            metadata=metadata or {},
            grpc_options=grpc_options or [],
        )

        self._channel: grpc.aio.Channel | None = None
        self._pool: ConnectionPool | None = None
        self._connected: bool = False

        # Namespaces (populated on connect)
        self._collections: CollectionsNamespace | None = None
        self._points: PointsNamespace | None = None
        self._vde: VDENamespace | None = None
        self._vectorai_stub: vectorai_grpc.ActianVectorAIStub | None = None

    # ── Properties ────────────────────────────────────────────────

    @property
    def collections(self) -> CollectionsNamespace:
        """Collections namespace (create, delete, list, info, …)."""
        self._ensure_connected()
        assert self._collections is not None
        return self._collections

    @property
    def points(self) -> PointsNamespace:
        """Points namespace (upsert, search, query, scroll, …)."""
        self._ensure_connected()
        assert self._points is not None
        return self._points

    @property
    def vde(self) -> VDENamespace:
        """VDE extensions namespace (rebuild, compact, stats, …)."""
        self._ensure_connected()
        assert self._vde is not None
        return self._vde

    @property
    def is_connected(self) -> bool:
        """Whether the client is connected to the server."""
        return self._connected

    # ── Connection lifecycle ──────────────────────────────────────

    async def connect(self) -> None:  # noqa: C901
        """Establish the gRPC channel and create service stubs.

        When ``pool_size > 1``, a :class:`ConnectionPool` is used for
        round-robin channel distribution to overcome HTTP/2
        ``MAX_CONCURRENT_STREAMS`` limits.

        Called automatically by the context manager (``async with``).
        Can also be called manually.
        """
        if self._connected:
            return

        cfg = self._config

        # Build interceptors
        interceptors: list[grpc.aio.UnaryUnaryClientInterceptor] = []
        if cfg.api_key:
            interceptors.append(AuthInterceptor(api_key=cfg.api_key))
        if cfg.max_retries > 0:
            interceptors.append(RetryInterceptor(max_retries=cfg.max_retries))
        if cfg.enable_tracing:
            interceptors.append(TracingInterceptor())
        if cfg.enable_logging:
            interceptors.append(LoggingInterceptor())
        if cfg.metadata:
            interceptors.append(MetadataInterceptor(metadata=list(cfg.metadata.items())))
        interceptors.append(UserAgentInterceptor())

        if cfg.pool_size > 1:
            # ── Pooled mode ───────────────────────────────────────────
            credentials = None
            if cfg.tls:
                credentials = create_credentials_from_files(
                    ca_cert_path=cfg.tls_ca_cert,
                    client_key_path=cfg.tls_client_key,
                    client_cert_path=cfg.tls_client_cert,
                )
            pool_cfg = PoolConfig(
                pool_size=cfg.pool_size,
                max_message_length=cfg.max_message_size,
            )
            self._pool = ConnectionPool(
                cfg.url,
                config=pool_cfg,
                credentials=credentials,
                interceptors=interceptors or None,
            )
            await self._pool.connect()
            # Distribute stubs across pool channels (round-robin)
            col_channel = self._pool.get_channel()
            pts_channel = self._pool.get_channel()
            ext_channel = self._pool.get_channel()
            vai_channel = self._pool.get_channel()
        else:
            # ── Single-channel mode ───────────────────────────────────
            options: list[tuple[str, Any]] = [
                ("grpc.max_receive_message_length", cfg.max_message_size),
                ("grpc.max_send_message_length", cfg.max_message_size),
                ("grpc.keepalive_time_ms", 30_000),
                ("grpc.keepalive_timeout_ms", 10_000),
                ("grpc.keepalive_permit_without_calls", True),
                ("grpc.http2.max_pings_without_data", 0),
                *cfg.grpc_options,
            ]
            if cfg.tls:
                credentials = create_credentials_from_files(
                    ca_cert_path=cfg.tls_ca_cert,
                    client_key_path=cfg.tls_client_key,
                    client_cert_path=cfg.tls_client_cert,
                )
                self._channel = grpc.aio.secure_channel(
                    cfg.url,
                    credentials,
                    options=options,
                    interceptors=interceptors or None,
                )
            else:
                self._channel = grpc.aio.insecure_channel(
                    cfg.url,
                    options=options,
                    interceptors=interceptors or None,
                )
            channel = self._channel

        # Create stubs — in pooled mode each service gets its own channel
        if self._pool is not None:
            col_stub = col_grpc.CollectionsStub(col_channel)
            pts_stub = pts_grpc.PointsStub(pts_channel)
            ext_stub = ext_grpc.CollectionsExtStub(ext_channel)
            self._vectorai_stub = vectorai_grpc.ActianVectorAIStub(vai_channel)
        else:
            col_stub = col_grpc.CollectionsStub(channel)
            pts_stub = pts_grpc.PointsStub(channel)
            ext_stub = ext_grpc.CollectionsExtStub(channel)
            self._vectorai_stub = vectorai_grpc.ActianVectorAIStub(channel)

        # Wire up namespaces
        self._collections = CollectionsNamespace(
            col_stub,
            timeout=cfg.timeout,
        )
        self._points = PointsNamespace(
            pts_stub,
            timeout=cfg.timeout,
        )
        self._vde = VDENamespace(
            ext_stub,
            timeout=cfg.timeout,
        )

        self._connected = True
        mode = f"pool={cfg.pool_size}" if cfg.pool_size > 1 else "single"
        logger.info("Connected to %s (TLS=%s, %s)", cfg.url, cfg.tls, mode)

        # Eagerly verify server is reachable
        try:
            await self.health_check(timeout=min(cfg.timeout or 5.0, 5.0))
        except Exception as e:
            # Revert connection state — server is not reachable
            await self.close()
            raise VaiConnectionError(
                f"Server at '{cfg.url}' is not reachable",
                code=ErrorCode.SERVICE_UNAVAILABLE,
            ) from e

    async def close(self) -> None:
        """Close the gRPC channel (or pool) and release resources."""
        if self._pool is not None:
            await self._pool.close()
            self._pool = None
        if self._channel is not None:
            await self._channel.close()
            self._channel = None
        self._connected = False
        self._collections = None
        self._points = None
        self._vde = None
        self._vectorai_stub = None
        logger.info("Disconnected")

    def _ensure_connected(self) -> None:
        """Raise if not connected."""
        if not self._connected:
            raise VaiConnectionError(
                "Client is not connected. Call connect() or use "
                "'async with AsyncVectorAIClient(...)' context manager.",
                code=ErrorCode.SERVICE_UNAVAILABLE,
            )

    # ── Context manager ───────────────────────────────────────────

    async def __aenter__(self) -> AsyncVectorAIClient:
        await self.connect()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        await self.close()

    # ── Top-level convenience ─────────────────────────────────────

    async def health_check(
        self,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Check server health.

        Returns
        -------
        Dict with ``title``, ``version``, and optional ``commit``.
        """
        self._ensure_connected()
        assert self._vectorai_stub is not None
        req = vectorai_pb.HealthCheckRequest()
        resp = await grpc_call(
            self._vectorai_stub.HealthCheck,
            req,
            timeout=timeout if timeout is not None else self._config.timeout,
            address=self._config.url,
        )
        result: dict[str, Any] = {
            "title": resp.title,
            "version": resp.version,
        }
        if resp.HasField("commit"):
            result["commit"] = resp.commit
        return result

    async def upload_points(
        self,
        collection_name: str,
        points: list[Any],
        *,
        batch_size: int = 256,
    ) -> int:
        """Upload points with automatic batching.

        Splits *points* into batches of *batch_size* and upserts each
        batch sequentially.  The ``RetryInterceptor`` (configured via
        *max_retries* on the client) handles transient gRPC errors at
        the RPC level, so no application-level retry loop is needed.

        Parameters
        ----------
        collection_name:
            Target collection.
        points:
            List of ``PointStruct`` instances.
        batch_size:
            Number of points per upsert call (default: 256).

        Returns
        -------
        Total number of points successfully uploaded.
        """
        self._ensure_connected()
        total = 0
        num_batches = (len(points) + batch_size - 1) // batch_size

        for i in range(0, len(points), batch_size):
            batch = points[i : i + batch_size]
            batch_num = i // batch_size + 1
            logger.debug("Uploading batch %d/%d (%d pts)", batch_num, num_batches, len(batch))
            await self.points.upsert(collection_name, batch)
            total += len(batch)

        return total

    def __repr__(self) -> str:
        status = "connected" if self._connected else "disconnected"
        return f"AsyncVectorAIClient(url={self._config.url!r}, {status})"
