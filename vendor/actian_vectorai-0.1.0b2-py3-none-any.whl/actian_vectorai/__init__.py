############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Actian VectorAI DB Python Client SDK.

Public API surface for ``actian_vectorai``.  Import directly::

    from actian_vectorai import (
        VectorAIClient,          # sync
        AsyncVectorAIClient,     # async
        VectorParams, Distance, PointStruct, ScoredPoint,
        Field, FilterBuilder,
    )
"""

__version__ = "0.1.0b2"

# ── Clients ─────────────────────────────────────────────────────────────────
from actian_vectorai.async_client import AsyncVectorAIClient  # noqa: F401

# ── Smart Batcher ───────────────────────────────────────────────────────────
from actian_vectorai.batcher import BatcherConfig, SmartBatcher  # noqa: F401
from actian_vectorai.client import VectorAIClient  # noqa: F401

# ── Exceptions ──────────────────────────────────────────────────────────────
from actian_vectorai.exceptions import (  # noqa: F401
    AuthenticationError,
    BatchError,
    ChannelClosedError,
    CircuitBreakerOpenError,
    ClientClosedError,
    CollectionExistsError,
    CollectionNotFoundError,
    CollectionNotReadyError,
    DimensionMismatchError,
    ErrorCode,
    InvalidCredentialsError,
    MaxRetriesExceededError,
    MessageSizeExceededError,
    PayloadError,
    PayloadKeyNotFoundError,
    PermissionDeniedError,
    PointNotFoundError,
    RateLimitError,
    ServerError,
    UnimplementedError,
    VectorAIError,
    from_grpc_error,
    from_http_error,
    get_retry_delay,
    is_retryable,
)
from actian_vectorai.exceptions import (
    ConnectionError as VectorAIConnectionError,
)
from actian_vectorai.exceptions import (
    ConnectionRefusedError as VaiConnectionRefusedError,
)
from actian_vectorai.exceptions import (
    ConnectionTimeoutError as VaiConnectionTimeoutError,
)
from actian_vectorai.exceptions import (
    TimeoutError as VectorAITimeoutError,
)
from actian_vectorai.exceptions import (
    ValidationError as VectorAIValidationError,
)

# ── Filters ─────────────────────────────────────────────────────────────────
from actian_vectorai.filters import (  # noqa: F401
    Field,
    FilterBuilder,
    has_id,
    has_vector,
    is_empty,
    is_null,
    nested,
)

# ── Hybrid Fusion ───────────────────────────────────────────────────────────
from actian_vectorai.hybrid import (  # noqa: F401
    distribution_based_score_fusion,
    reciprocal_rank_fusion,
)

# ── Models ──────────────────────────────────────────────────────────────────
from actian_vectorai.models import *  # noqa: F401,F403

# ── Public API surface ──────────────────────────────────────────────────────
# All model names are re-exported from actian_vectorai.models via wildcard.
# This __all__ lists the explicit non-model names plus the models __all__.
from actian_vectorai.models import __all__ as _models_all

# ── Transport (advanced) ────────────────────────────────────────────────────
from actian_vectorai.transport import (  # noqa: F401
    ConnectionPool,
    PoolConfig,
)

__all__ = [
    # Clients
    "VectorAIClient",
    "AsyncVectorAIClient",
    # Batcher
    "SmartBatcher",
    "BatcherConfig",
    # Exceptions
    "ErrorCode",
    "VectorAIError",
    "ServerError",
    "CollectionNotFoundError",
    "CollectionExistsError",
    "CollectionNotReadyError",
    "PointNotFoundError",
    "DimensionMismatchError",
    "PayloadError",
    "PayloadKeyNotFoundError",
    "BatchError",
    "RateLimitError",
    "MessageSizeExceededError",
    "MaxRetriesExceededError",
    "CircuitBreakerOpenError",
    "ClientClosedError",
    "UnimplementedError",
    "AuthenticationError",
    "InvalidCredentialsError",
    "PermissionDeniedError",
    "ChannelClosedError",
    "VectorAIConnectionError",
    "VaiConnectionRefusedError",
    "VaiConnectionTimeoutError",
    "VectorAITimeoutError",
    "VectorAIValidationError",
    "from_grpc_error",
    "from_http_error",
    "get_retry_delay",
    "is_retryable",
    # Filters
    "Field",
    "FilterBuilder",
    "has_id",
    "has_vector",
    "is_empty",
    "is_null",
    "nested",
    # Hybrid fusion
    "reciprocal_rank_fusion",
    "distribution_based_score_fusion",
    # Transport
    "ConnectionPool",
    "PoolConfig",
    # Version
    "__version__",
    # All model/enum names
    *_models_all,
]
