############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Point-related Pydantic models with proto conversion.

Maps user-facing messages from ``points.proto`` and ``points_service.proto``.
"""

from __future__ import annotations

from typing import Any, Optional, Union

import numpy as np
from pydantic import BaseModel, Field

from actian_vectorai.models.common import (
    Filter,
    PointId,
    PointIdValue,
    _point_id_to_proto,
)
from actian_vectorai.models.enums import (
    Direction,
    ReadConsistencyType,
    UpdateStatus,
    WriteOrderingType,
)
from actian_vectorai.proto import actian_vectorai_json_with_int_pb2 as json_pb
from actian_vectorai.proto import actian_vectorai_points_pb2 as pts_pb

__all__ = [
    # Core vector types
    "DenseVector",
    "SparseVector",
    "MultiDenseVector",
    # Point types
    "PointStruct",
    "RetrievedPoint",
    "ScoredPoint",
    "PointGroup",
    "GroupsResult",
    # Search params
    "SearchParams",
    "QuantizationSearchParams",
    "AcornSearchParams",
    # Write/Read config
    "WriteOrdering",
    "ReadConsistency",
    # Selectors
    "WithPayloadSelector",
    "WithVectorsSelector",
    # Ordering
    "OrderBy",
    # Update result
    "UpdateResult",
    "CountResult",
    # Facet
    "FacetHit",
    "FacetValue",
    # Search matrix
    "SearchMatrixPair",
    # Query types
    "PrefetchQuery",
    # Usage
    "Usage",
    "HardwareUsage",
    # Optional fast-path (msgspec)
    "HAS_MSGSPEC",
]


# ─── Payload Helpers ──────────────────────────────────────────────────


def _payload_to_proto(payload: dict[str, Any]) -> dict[str, json_pb.Value]:
    """Convert a Python dict to proto Value map."""
    result = {}
    for k, v in payload.items():
        result[k] = _python_to_value(v)
    return result


def _python_to_value(v: Any) -> json_pb.Value:
    """Convert a Python value to proto Value."""
    pb = json_pb.Value()
    if v is None:
        pb.null_value = 0
    elif isinstance(v, bool):
        pb.bool_value = v
    elif isinstance(v, int):
        pb.integer_value = v
    elif isinstance(v, float):
        pb.double_value = v
    elif isinstance(v, str):
        pb.string_value = v
    elif isinstance(v, list):
        list_val = json_pb.ListValue()
        for item in v:
            list_val.values.append(_python_to_value(item))
        pb.list_value.CopyFrom(list_val)
    elif isinstance(v, dict):
        struct = json_pb.Struct()
        for sk, sv in v.items():
            struct.fields[sk].CopyFrom(_python_to_value(sv))
        pb.struct_value.CopyFrom(struct)
    else:
        pb.string_value = str(v)
    return pb


def _value_to_python(pb: json_pb.Value) -> Any:
    """Convert a proto Value to Python."""
    which = pb.WhichOneof("kind")
    if which == "null_value":
        return None
    if which == "bool_value":
        return pb.bool_value
    if which == "integer_value":
        return pb.integer_value
    if which == "double_value":
        return pb.double_value
    if which == "string_value":
        return pb.string_value
    if which == "list_value":
        return [_value_to_python(item) for item in pb.list_value.values]
    if which == "struct_value":
        return {k: _value_to_python(v) for k, v in pb.struct_value.fields.items()}
    return None


def _proto_payload_to_dict(payload_map: Any) -> dict[str, Any]:
    """Convert proto payload map to Python dict."""
    return {k: _value_to_python(v) for k, v in payload_map.items()}


# ─── Core Vector Types ───────────────────────────────────────────────


class DenseVector(BaseModel):
    """Dense float vector."""

    data: list[float]

    def to_proto(self) -> pts_pb.DenseVector:
        return pts_pb.DenseVector(data=self.data)

    @classmethod
    def from_proto(cls, pb: pts_pb.DenseVector) -> DenseVector:
        return cls(data=list(pb.data))

    @classmethod
    def from_list(cls, data: list[float]) -> DenseVector:
        return cls(data=data)


class SparseVector(BaseModel):
    """Sparse vector with indices and values."""

    values: list[float]
    indices: list[int]

    def to_proto(self) -> pts_pb.SparseVector:
        return pts_pb.SparseVector(values=self.values, indices=self.indices)

    @classmethod
    def from_proto(cls, pb: pts_pb.SparseVector) -> SparseVector:
        return cls(values=list(pb.values), indices=list(pb.indices))


class MultiDenseVector(BaseModel):
    """Multi-vector (list of dense vectors)."""

    vectors: list[DenseVector]

    def to_proto(self) -> pts_pb.MultiDenseVector:
        return pts_pb.MultiDenseVector(vectors=[v.to_proto() for v in self.vectors])

    @classmethod
    def from_proto(cls, pb: pts_pb.MultiDenseVector) -> MultiDenseVector:
        return cls(vectors=[DenseVector.from_proto(v) for v in pb.vectors])


# ─── Vectors (oneof wrapper) ─────────────────────────────────────────


def _build_vectors_proto(
    vector: Union[
        list[float],
        "np.ndarray[Any, Any]",
        DenseVector,
        SparseVector,
        MultiDenseVector,
        dict[str, Any],
    ],
) -> pts_pb.Vectors:
    """Build a Vectors proto from various input types."""
    pb = pts_pb.Vectors()

    if isinstance(vector, np.ndarray):
        # Fast path: numpy array — cast to float32 and assign directly
        inner = pts_pb.Vector()
        arr = vector.astype(np.float32) if vector.dtype != np.float32 else vector
        inner.dense.CopyFrom(pts_pb.DenseVector(data=arr))
        pb.vector.CopyFrom(inner)
    elif isinstance(vector, list):
        # Simple list of floats → single dense vector
        inner = pts_pb.Vector()
        inner.dense.CopyFrom(pts_pb.DenseVector(data=vector))
        pb.vector.CopyFrom(inner)
    elif isinstance(vector, DenseVector):
        inner = pts_pb.Vector()
        inner.dense.CopyFrom(vector.to_proto())
        pb.vector.CopyFrom(inner)
    elif isinstance(vector, SparseVector):
        inner = pts_pb.Vector()
        inner.sparse.CopyFrom(vector.to_proto())
        pb.vector.CopyFrom(inner)
    elif isinstance(vector, MultiDenseVector):
        inner = pts_pb.Vector()
        inner.multi_dense.CopyFrom(vector.to_proto())
        pb.vector.CopyFrom(inner)
    elif isinstance(vector, dict):
        # Named vectors: {"name": [1.0, 2.0, ...]} or {"name": DenseVector(...)}
        named = pts_pb.NamedVectors()
        for name, vec in vector.items():
            v = pts_pb.Vector()
            if isinstance(vec, list):
                v.dense.CopyFrom(pts_pb.DenseVector(data=vec))
            elif isinstance(vec, DenseVector):
                v.dense.CopyFrom(vec.to_proto())
            elif isinstance(vec, SparseVector):
                v.sparse.CopyFrom(vec.to_proto())
            elif isinstance(vec, MultiDenseVector):
                v.multi_dense.CopyFrom(vec.to_proto())
            named.vectors[name].CopyFrom(v)
        pb.vectors.CopyFrom(named)
    return pb


def _parse_vectors_output(
    pb: pts_pb.VectorsOutput,
) -> Optional[Union[list[float], list[list[float]], dict[str, list[float]]]]:
    """Parse VectorsOutput proto to Python types."""
    which = pb.WhichOneof("vectors_options")
    if which == "vector":
        vo = pb.vector
        inner = vo.WhichOneof("vector")
        if inner == "dense":
            return list(vo.dense.data)
        if inner == "sparse":
            return list(vo.sparse.values)
        if inner == "multi_dense":
            return [list(v.data) for v in vo.multi_dense.vectors]
    elif which == "vectors":
        result = {}
        for name, vo in pb.vectors.vectors.items():
            inner = vo.WhichOneof("vector")
            if inner == "dense":
                result[name] = list(vo.dense.data)
            elif inner == "sparse":
                result[name] = list(vo.sparse.values)
        return result
    return None


# ─── Write / Read Config ─────────────────────────────────────────────


class WriteOrdering(BaseModel):
    """Write ordering guarantees."""

    type: WriteOrderingType = WriteOrderingType.Weak

    def to_proto(self) -> pts_pb.WriteOrdering:
        return pts_pb.WriteOrdering(type=self.type.value)

    @classmethod
    def from_proto(cls, pb: pts_pb.WriteOrdering) -> WriteOrdering:
        return cls(type=WriteOrderingType(pb.type))


class ReadConsistency(BaseModel):
    """Read consistency configuration."""

    type: Optional[ReadConsistencyType] = None
    factor: Optional[int] = None

    def to_proto(self) -> pts_pb.ReadConsistency:
        pb = pts_pb.ReadConsistency()
        if self.type is not None:
            pb.type = self.type.value
        elif self.factor is not None:
            pb.factor = self.factor
        return pb

    @classmethod
    def from_proto(cls, pb: pts_pb.ReadConsistency) -> ReadConsistency:
        which = pb.WhichOneof("value")
        if which == "type":
            return cls(type=ReadConsistencyType(pb.type))
        if which == "factor":
            return cls(factor=pb.factor)
        return cls()


# ─── Selectors ───────────────────────────────────────────────────────


class WithPayloadSelector(BaseModel):
    """Select which payload fields to include/exclude."""

    enable: Optional[bool] = None
    include: Optional[list[str]] = None
    exclude: Optional[list[str]] = None

    def to_proto(self) -> pts_pb.WithPayloadSelector:
        pb = pts_pb.WithPayloadSelector()
        if self.include is not None:
            pb.include.CopyFrom(pts_pb.PayloadIncludeSelector(fields=self.include))
        elif self.exclude is not None:
            pb.exclude.CopyFrom(pts_pb.PayloadExcludeSelector(fields=self.exclude))
        elif self.enable is not None:
            pb.enable = self.enable
        else:
            pb.enable = True
        return pb

    @classmethod
    def from_proto(cls, pb: pts_pb.WithPayloadSelector) -> WithPayloadSelector:
        which = pb.WhichOneof("selector_options")
        if which == "enable":
            return cls(enable=pb.enable)
        if which == "include":
            return cls(include=list(pb.include.fields))
        if which == "exclude":
            return cls(exclude=list(pb.exclude.fields))
        return cls(enable=True)


class WithVectorsSelector(BaseModel):
    """Select which vectors to include in response."""

    enable: Optional[bool] = None
    include: Optional[list[str]] = None

    def to_proto(self) -> pts_pb.WithVectorsSelector:
        pb = pts_pb.WithVectorsSelector()
        if self.include is not None:
            pb.include.CopyFrom(pts_pb.VectorsSelector(names=self.include))
        elif self.enable is not None:
            pb.enable = self.enable
        else:
            pb.enable = False
        return pb

    @classmethod
    def from_proto(cls, pb: pts_pb.WithVectorsSelector) -> WithVectorsSelector:
        which = pb.WhichOneof("selector_options")
        if which == "enable":
            return cls(enable=pb.enable)
        if which == "include":
            return cls(include=list(pb.include.names))
        return cls(enable=False)


# ─── Search Params ───────────────────────────────────────────────────


class QuantizationSearchParams(BaseModel):
    """Quantization search parameters."""

    ignore: Optional[bool] = None
    rescore: Optional[bool] = None
    oversampling: Optional[float] = None

    def to_proto(self) -> pts_pb.QuantizationSearchParams:
        pb = pts_pb.QuantizationSearchParams()
        if self.ignore is not None:
            pb.ignore = self.ignore
        if self.rescore is not None:
            pb.rescore = self.rescore
        if self.oversampling is not None:
            pb.oversampling = self.oversampling
        return pb

    @classmethod
    def from_proto(cls, pb: pts_pb.QuantizationSearchParams) -> QuantizationSearchParams:
        return cls(
            ignore=pb.ignore if pb.HasField("ignore") else None,
            rescore=pb.rescore if pb.HasField("rescore") else None,
            oversampling=pb.oversampling if pb.HasField("oversampling") else None,
        )


class AcornSearchParams(BaseModel):
    """ACORN search parameters for filtered HNSW search."""

    enable: Optional[bool] = None
    max_selectivity: Optional[float] = None

    def to_proto(self) -> pts_pb.AcornSearchParams:
        pb = pts_pb.AcornSearchParams()
        if self.enable is not None:
            pb.enable = self.enable
        if self.max_selectivity is not None:
            pb.max_selectivity = self.max_selectivity
        return pb

    @classmethod
    def from_proto(cls, pb: pts_pb.AcornSearchParams) -> AcornSearchParams:
        return cls(
            enable=pb.enable if pb.HasField("enable") else None,
            max_selectivity=pb.max_selectivity if pb.HasField("max_selectivity") else None,
        )


class SearchParams(BaseModel):
    """Vector search parameters."""

    hnsw_ef: Optional[int] = None
    exact: Optional[bool] = None
    quantization: Optional[QuantizationSearchParams] = None
    indexed_only: Optional[bool] = None
    acorn: Optional[AcornSearchParams] = None
    # VDE extensions
    ivf_nprobe: Optional[int] = None
    extra_params_json: Optional[str] = None

    def to_proto(self) -> pts_pb.SearchParams:
        pb = pts_pb.SearchParams()
        if self.hnsw_ef is not None:
            pb.hnsw_ef = self.hnsw_ef
        if self.exact is not None:
            pb.exact = self.exact
        if self.quantization is not None:
            pb.quantization.CopyFrom(self.quantization.to_proto())
        if self.indexed_only is not None:
            pb.indexed_only = self.indexed_only
        if self.acorn is not None:
            pb.acorn.CopyFrom(self.acorn.to_proto())
        if self.ivf_nprobe is not None:
            pb.ivf_nprobe = self.ivf_nprobe
        if self.extra_params_json is not None:
            pb.extra_params_json = self.extra_params_json
        return pb

    @classmethod
    def from_proto(cls, pb: pts_pb.SearchParams) -> SearchParams:
        return cls(
            hnsw_ef=pb.hnsw_ef if pb.HasField("hnsw_ef") else None,
            exact=pb.exact if pb.HasField("exact") else None,
            quantization=(
                QuantizationSearchParams.from_proto(pb.quantization)
                if pb.HasField("quantization")
                else None
            ),
            indexed_only=pb.indexed_only if pb.HasField("indexed_only") else None,
            acorn=(AcornSearchParams.from_proto(pb.acorn) if pb.HasField("acorn") else None),
            ivf_nprobe=pb.ivf_nprobe if pb.HasField("ivf_nprobe") else None,
            extra_params_json=(pb.extra_params_json if pb.HasField("extra_params_json") else None),
        )


# ─── Order By ────────────────────────────────────────────────────────


class OrderBy(BaseModel):
    """Order by a payload field."""

    key: str
    direction: Optional[Direction] = None

    def to_proto(self) -> pts_pb.OrderBy:
        pb = pts_pb.OrderBy(key=self.key)
        if self.direction is not None:
            pb.direction = self.direction.value
        return pb

    @classmethod
    def from_proto(cls, pb: pts_pb.OrderBy) -> OrderBy:
        return cls(
            key=pb.key,
            direction=Direction(pb.direction) if pb.HasField("direction") else None,
        )


# ─── Point Types ─────────────────────────────────────────────────────


class PointStruct(BaseModel):
    """A point for upsert: ID + vector + optional payload.

    Accepts flexible vector formats:
    - ``list[float]`` for a single dense vector
    - ``DenseVector`` / ``SparseVector`` / ``MultiDenseVector``
    - ``dict[str, list[float]]`` for named vectors

    Examples:
        >>> PointStruct(id=1, vector=[0.1, 0.2, 0.3])
        >>> PointStruct(id="abc-uuid", vector={"text": [0.1, 0.2]}, payload={"k": "v"})
    """

    id: PointIdValue
    vector: Union[list[float], DenseVector, SparseVector, MultiDenseVector, dict[str, Any]]
    payload: Optional[dict[str, Any]] = None

    model_config = {"arbitrary_types_allowed": True}

    def to_proto(self) -> pts_pb.PointStruct:
        pb = pts_pb.PointStruct()
        pb.id.CopyFrom(_point_id_to_proto(self.id))
        if isinstance(self.vector, np.ndarray):
            # Fast path: numpy → protobuf without intermediate Python list
            inner = pts_pb.Vector()
            arr = self.vector.astype(np.float32) if self.vector.dtype != np.float32 else self.vector
            inner.dense.CopyFrom(pts_pb.DenseVector(data=arr))
            vectors_pb = pts_pb.Vectors()
            vectors_pb.vector.CopyFrom(inner)
            pb.vectors.CopyFrom(vectors_pb)
        else:
            pb.vectors.CopyFrom(_build_vectors_proto(self.vector))
        if self.payload:
            for k, v in _payload_to_proto(self.payload).items():
                pb.payload[k].CopyFrom(v)
        return pb

    @classmethod
    def from_proto(cls, pb: pts_pb.PointStruct) -> PointStruct:
        pid = PointId.from_proto(pb.id)
        id_val: PointIdValue = pid.num if pid.num is not None else (pid.uuid or 0)
        vectors: Any = _parse_vectors_output(pb.vectors) if pb.HasField("vectors") else []
        payload = _proto_payload_to_dict(pb.payload) if pb.payload else None
        return cls(id=id_val, vector=vectors or [], payload=payload)

    def __repr__(self) -> str:
        vec_desc = (
            f"[{len(self.vector)} dims]"
            if isinstance(self.vector, list)
            else str(type(self.vector).__name__)
        )
        return f"PointStruct(id={self.id}, vector={vec_desc}, payload={self.payload})"


class ScoredPoint(BaseModel):
    """A point returned from search with a similarity score."""

    id: PointIdValue
    score: float
    payload: Optional[dict[str, Any]] = None
    vectors: Optional[Any] = None
    version: int = 0

    @classmethod
    def from_proto(cls, pb: pts_pb.ScoredPoint) -> ScoredPoint:
        pid = PointId.from_proto(pb.id)
        id_val: PointIdValue = pid.num if pid.num is not None else (pid.uuid or 0)
        payload = _proto_payload_to_dict(pb.payload) if pb.payload else None
        vectors = _parse_vectors_output(pb.vectors) if pb.HasField("vectors") else None
        return cls(
            id=id_val,
            score=pb.score,
            payload=payload,
            vectors=vectors,
            version=pb.version,
        )

    def __repr__(self) -> str:
        parts = [f"id={self.id}", f"score={self.score:.4f}"]
        if self.payload:
            parts.append(f"payload={self.payload}")
        return f"ScoredPoint({', '.join(parts)})"


class RetrievedPoint(BaseModel):
    """A point retrieved by ID (get/scroll)."""

    id: PointIdValue
    payload: Optional[dict[str, Any]] = None
    vectors: Optional[Any] = None

    @classmethod
    def from_proto(cls, pb: pts_pb.RetrievedPoint) -> RetrievedPoint:
        pid = PointId.from_proto(pb.id)
        id_val: PointIdValue = pid.num if pid.num is not None else (pid.uuid or 0)
        payload = _proto_payload_to_dict(pb.payload) if pb.payload else None
        vectors = _parse_vectors_output(pb.vectors) if pb.HasField("vectors") else None
        return cls(id=id_val, payload=payload, vectors=vectors)


# ─── Groups ──────────────────────────────────────────────────────────


class GroupId(BaseModel):
    """Group identifier (oneof: unsigned, integer, or string)."""

    value: Union[int, str]

    @classmethod
    def from_proto(cls, pb: pts_pb.GroupId) -> GroupId:
        which = pb.WhichOneof("kind")
        if which == "unsigned_value":
            return cls(value=pb.unsigned_value)
        if which == "integer_value":
            return cls(value=pb.integer_value)
        if which == "string_value":
            return cls(value=pb.string_value)
        return cls(value=0)


class PointGroup(BaseModel):
    """A group of scored points."""

    id: GroupId
    hits: list[ScoredPoint] = Field(default_factory=list)
    lookup: Optional[RetrievedPoint] = None

    @classmethod
    def from_proto(cls, pb: pts_pb.PointGroup) -> PointGroup:
        return cls(
            id=GroupId.from_proto(pb.id),
            hits=[ScoredPoint.from_proto(h) for h in pb.hits],
            lookup=(RetrievedPoint.from_proto(pb.lookup) if pb.HasField("lookup") else None),
        )


class GroupsResult(BaseModel):
    """Groups result from group-by operations."""

    groups: list[PointGroup] = Field(default_factory=list)

    @classmethod
    def from_proto(cls, pb: pts_pb.GroupsResult) -> GroupsResult:
        return cls(groups=[PointGroup.from_proto(g) for g in pb.groups])


# ─── Update / Count Results ──────────────────────────────────────────


class UpdateResult(BaseModel):
    """Result of a point update operation."""

    operation_id: Optional[int] = None
    status: UpdateStatus = UpdateStatus.UnknownUpdateStatus
    deleted_ids: Optional[list] = None
    failed_ids: Optional[list] = None

    @classmethod
    def from_proto(cls, pb: pts_pb.UpdateResult) -> UpdateResult:
        return cls(
            operation_id=pb.operation_id if pb.HasField("operation_id") else None,
            status=UpdateStatus(pb.status),
        )

    def __repr__(self) -> str:
        parts = f"operation_id={self.operation_id}, status={self.status.name}"
        if self.deleted_ids is not None:
            parts += f", deleted_ids={self.deleted_ids}"
        if self.failed_ids is not None:
            parts += f", failed_ids={self.failed_ids}"
        return f"UpdateResult({parts})"

    def __str__(self) -> str:
        return self.__repr__()


class CountResult(BaseModel):
    """Count query result."""

    count: int = 0

    @classmethod
    def from_proto(cls, pb: pts_pb.CountResult) -> CountResult:
        return cls(count=pb.count)


# ─── Facet Types ─────────────────────────────────────────────────────


class FacetValue(BaseModel):
    """A facet value (string, integer, or bool)."""

    value: Union[str, int, bool]

    @classmethod
    def from_proto(cls, pb: pts_pb.FacetValue) -> FacetValue:
        which = pb.WhichOneof("variant")
        if which == "string_value":
            return cls(value=pb.string_value)
        if which == "integer_value":
            return cls(value=pb.integer_value)
        if which == "bool_value":
            return cls(value=pb.bool_value)
        return cls(value="")


class FacetHit(BaseModel):
    """A facet count result."""

    value: FacetValue
    count: int = 0

    @classmethod
    def from_proto(cls, pb: pts_pb.FacetHit) -> FacetHit:
        return cls(value=FacetValue.from_proto(pb.value), count=pb.count)


# ─── Search Matrix ───────────────────────────────────────────────────


class SearchMatrixPair(BaseModel):
    """A pair of points with similarity score."""

    a: PointIdValue
    b: PointIdValue
    score: float = 0.0

    @classmethod
    def from_proto(cls, pb: pts_pb.SearchMatrixPair) -> SearchMatrixPair:
        a_id = PointId.from_proto(pb.a)
        b_id = PointId.from_proto(pb.b)
        return cls(
            a=a_id.num if a_id.num is not None else (a_id.uuid or 0),
            b=b_id.num if b_id.num is not None else (b_id.uuid or 0),
            score=pb.score,
        )


# ─── Prefetch Query ──────────────────────────────────────────────────


def _build_prefetch_query_proto(query: Any) -> pts_pb.Query | None:
    """Serialize a user-facing query value into a ``pts_pb.Query`` proto.

    Accepts the same input forms as ``PointsNamespace.query(query=...)``.
    """
    if isinstance(query, pts_pb.Query):
        return query
    if isinstance(query, (list, np.ndarray)):
        floats = [float(v) for v in query]
        q = pts_pb.Query()
        vi = pts_pb.VectorInput()
        vi.dense.data.extend(floats)
        q.nearest.CopyFrom(vi)
        return q
    if isinstance(query, DenseVector):
        q = pts_pb.Query()
        vi = pts_pb.VectorInput()
        vi.dense.data.extend(query.data)
        q.nearest.CopyFrom(vi)
        return q
    if isinstance(query, dict):
        q = pts_pb.Query()
        if "nearest" in query:
            vi = pts_pb.VectorInput()
            vi.dense.data.extend([float(v) for v in query["nearest"]])
            q.nearest.CopyFrom(vi)
        elif "fusion" in query:
            q.fusion = query["fusion"]
        elif "order_by" in query:
            ob = query["order_by"]
            if isinstance(ob, str):
                q.order_by.key = ob
            else:
                q.order_by.CopyFrom(ob.to_proto())
        elif "sample" in query:
            q.sample = query["sample"]
        return q
    return None


class PrefetchQuery(BaseModel):
    """Sub-query for prefetch in Query API.

    Parameters
    ----------
    query:
        The query for this prefetch stage.  Accepts the same forms as
        ``points.query(query=...)``:

        - ``list[float]`` / ``np.ndarray`` / ``DenseVector`` — nearest-neighbour
        - ``{"fusion": Fusion.RRF}`` or ``{"fusion": Fusion.DBSF}`` — score fusion
          (required when this node has sub-``prefetch`` stages)
        - ``{"order_by": "field"}`` — order by payload field

        Leaf prefetch nodes (no sub-prefetches) **must** supply a ``query``.
        Non-leaf nodes (with sub-prefetches) **must** supply a fusion query.
    prefetch:
        Nested sub-queries executed before this stage.
    using:
        Named vector space to search in.
    filter:
        Payload filter applied to this prefetch stage.
    params:
        Search parameters (ef, exact, etc.).
    score_threshold:
        Minimum score for a result to be kept.
    limit:
        Maximum candidates returned by this stage.
    """

    query: Any | None = None
    prefetch: list[PrefetchQuery] = Field(default_factory=list)
    using: Optional[str] = None
    filter: Optional[Filter] = None
    params: Optional[SearchParams] = None
    score_threshold: Optional[float] = None
    limit: Optional[int] = None

    def to_proto(self) -> pts_pb.PrefetchQuery:
        pb = pts_pb.PrefetchQuery()
        # Serialize query — same input forms as PointsNamespace.query()
        if self.query is not None:
            q_proto = _build_prefetch_query_proto(self.query)
            if q_proto is not None:
                pb.query.CopyFrom(q_proto)
        for pf in self.prefetch:
            pb.prefetch.append(pf.to_proto())
        if self.using is not None:
            pb.using = self.using
        if self.filter is not None:
            pb.filter.CopyFrom(self.filter.to_proto())
        if self.params is not None:
            pb.params.CopyFrom(self.params.to_proto())
        if self.score_threshold is not None:
            pb.score_threshold = self.score_threshold
        if self.limit is not None:
            pb.limit = self.limit
        return pb


# Rebuild for self-reference
PrefetchQuery.model_rebuild()


# ─── Usage ───────────────────────────────────────────────────────────


class HardwareUsage(BaseModel):
    """Hardware usage metrics."""

    cpu: int = 0
    payload_io_read: int = 0
    payload_io_write: int = 0
    payload_index_io_read: int = 0
    payload_index_io_write: int = 0
    vector_io_read: int = 0
    vector_io_write: int = 0

    @classmethod
    def from_proto(cls, pb: pts_pb.HardwareUsage) -> HardwareUsage:
        return cls(
            cpu=pb.cpu,
            payload_io_read=pb.payload_io_read,
            payload_io_write=pb.payload_io_write,
            payload_index_io_read=pb.payload_index_io_read,
            payload_index_io_write=pb.payload_index_io_write,
            vector_io_read=pb.vector_io_read,
            vector_io_write=pb.vector_io_write,
        )


class Usage(BaseModel):
    """Usage metrics from operations."""

    hardware: Optional[HardwareUsage] = None

    @classmethod
    def from_proto(cls, pb: pts_pb.Usage) -> Usage:
        return cls(
            hardware=(HardwareUsage.from_proto(pb.hardware) if pb.HasField("hardware") else None),
        )


# ─── Optional Fast-Path Types (msgspec) ──────────────────────────────
#
# Opt-in via ``pip install actian-vectorai[fast]``.
# These bypass Pydantic validation overhead on hot-path data-plane
# objects (bulk upserts, search results).  GC is disabled for throughput.

try:
    import msgspec

    class FastDenseVector(msgspec.Struct, gc=False):  # type: ignore[misc,call-arg]
        """High-performance dense vector for bulk operations."""

        data: list[float]

    class FastPointStruct(msgspec.Struct, gc=False):  # type: ignore[misc,call-arg]
        """High-performance point for bulk upserts."""

        id: int | str
        vector: list[float]
        payload: dict[str, Any] | None = None

    class FastScoredPoint(msgspec.Struct, gc=False):  # type: ignore[misc,call-arg]
        """High-performance scored point for search results."""

        id: int | str
        version: int
        score: float
        vector: list[float] | None = None
        payload: dict[str, Any] | None = None

    HAS_MSGSPEC = True

except ImportError:
    HAS_MSGSPEC = False
