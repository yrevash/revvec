############################################################
#
# Copyright (C) 2025 - Actian Corp.
#
############################################################

"""Models subpackage — Pydantic v2 models and IntEnum types.

Organized into modules:
- ``enums``: Proto-aligned IntEnum classes
- ``common``: Filter, PointId, Geo types (actian_vectorai_common.proto)
- ``collections``: Collection config, info, params (collections.proto)
- ``points``: Vector, Point, Search types (points.proto)
- ``vde``: VDE extension types (actian_vectorai_collections_ext.proto, actian_vectorai_index.proto)
"""

# Aggregate __all__ from sub-modules for explicit wildcard export control.
from actian_vectorai.models import collections as _collections
from actian_vectorai.models import common as _common
from actian_vectorai.models import enums as _enums
from actian_vectorai.models import points as _points
from actian_vectorai.models import vde as _vde
from actian_vectorai.models.collections import *  # noqa: F401, F403
from actian_vectorai.models.common import *  # noqa: F401, F403
from actian_vectorai.models.enums import *  # noqa: F401, F403
from actian_vectorai.models.points import *  # noqa: F401, F403
from actian_vectorai.models.vde import *  # noqa: F401, F403

__all__ = [
    *_collections.__all__,
    *_common.__all__,
    *_enums.__all__,
    *_points.__all__,
    *_vde.__all__,
]
